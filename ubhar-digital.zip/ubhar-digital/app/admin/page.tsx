import { AdminDashboard } from '@/components/admin/AdminDashboard';
import { getAuthors } from '@/lib/content';
import { categories } from '@/lib/categories';
import articles from '@/data/articles.json';
import breaking from '@/data/breaking.json';
import type { Article, BreakingItem } from '@/lib/types';

/**
 * Demo content dashboard. Works fully in the browser (drafts saved in localStorage)
 * and exports JSON that replaces /data/*.json. When a CMS/database is connected,
 * swap the save/export handlers for API calls — see README → "Managing news".
 */
export default async function AdminPage() {
  return (
    <AdminDashboard
      initialArticles={articles as Article[]}
      initialBreaking={breaking as BreakingItem[]}
      authors={await getAuthors()}
      categories={categories}
    />
  );
}
