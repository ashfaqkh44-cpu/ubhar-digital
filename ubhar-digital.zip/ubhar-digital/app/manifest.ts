import type { MetadataRoute } from 'next';

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'اُڀار ڊجيٽل — UBHAR Digital',
    short_name: 'اُڀار',
    description: 'خبر، نظر ۽ آواز عوام جو.',
    start_url: '/',
    display: 'standalone',
    dir: 'rtl',
    lang: 'sd',
    background_color: '#0B0B0F',
    theme_color: '#0B0B0F',
    icons: [{ src: '/images/logo/ubhar-icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' }],
  };
}
