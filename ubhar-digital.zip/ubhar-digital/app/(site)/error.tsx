'use client';

import { useEffect } from 'react';

export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error);
  }, [error]);
  return (
    <div className="container-x py-24 text-center">
      <h1 className="text-3xl">معاف ڪجو، ڪجهه غلط ٿي ويو</h1>
      <p className="mt-3 text-slate">صفحو لوڊ نه ٿي سگهيو. مهرباني ڪري ٻيهر ڪوشش ڪريو.</p>
      <button type="button" onClick={reset} className="mt-6 inline-flex h-12 items-center bg-brand px-6 font-bold text-white hover:bg-brand-dark">
        ٻيهر ڪوشش ڪريو
      </button>
    </div>
  );
}
