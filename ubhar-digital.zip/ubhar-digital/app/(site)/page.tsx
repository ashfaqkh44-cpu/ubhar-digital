import { HeroNews } from '@/components/HeroNews';
import { NewsCard } from '@/components/NewsCard';
import { SectionHeading } from '@/components/SectionHeading';
import { CategorySection } from '@/components/CategorySection';
import { VideoSection } from '@/components/VideoSection';
import { OpinionSection } from '@/components/OpinionSection';
import { MostRead } from '@/components/MostRead';
import { PublicVoice } from '@/components/PublicVoice';
import { Newsletter } from '@/components/Newsletter';
import { getCategory } from '@/lib/categories';
import { getArticlesByCategory, getAuthor, getHeroArticles, getLatest, getMostRead } from '@/lib/content';
import { site } from '@/lib/site';
import type { CategorySlug } from '@/lib/types';

export const revalidate = 300; // re-generate at most every 5 minutes (useful once a CMS is connected)

export default async function HomePage() {
  const hero = await getHeroArticles(4);
  const heroSlugs = hero.map((a) => a.slug);
  const [latest, mostRead, videos, opinion, voices] = await Promise.all([
    getLatest(6, heroSlugs),
    getMostRead(6),
    getArticlesByCategory('videos', 5),
    getArticlesByCategory('opinion', 4),
    getArticlesByCategory('public-voice', 4),
  ]);
  const opinionItems = await Promise.all(opinion.map(async (article) => ({ article, author: await getAuthor(article.authorId) })));

  const section = async (slug: CategorySlug, n = 5) => ({ category: getCategory(slug)!, articles: await getArticlesByCategory(slug, n) });
  const [sindh, politics, pakistan, karachi, districts, world, society, education, culture] = await Promise.all([
    section('sindh'),
    section('politics', 4),
    section('pakistan', 4),
    section('karachi', 4),
    section('districts', 4),
    section('world', 4),
    section('society', 4),
    section('education', 4),
    section('culture', 5),
  ]);

  return (
    <>
      <h1 className="sr-only">
        {site.nameSd} — {site.sloganShort}
      </h1>

      <HeroNews main={hero[0]} secondary={hero.slice(1, 4)} />

      {/* Latest + Most read */}
      <section aria-labelledby="sec-latest" className="container-x py-12 md:py-14">
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-8 xl:col-span-9">
            <SectionHeading id="sec-latest" title="تازيون خبرون" href="/category/latest" />
            <div className="grid gap-x-6 gap-y-10 sm:grid-cols-2 xl:grid-cols-3">
              {latest.map((a) => (
                <NewsCard key={a.slug} article={a} />
              ))}
            </div>
          </div>
          <div className="lg:col-span-4 xl:col-span-3">
            <div className="lg:sticky lg:top-20">
              <MostRead articles={mostRead} />
            </div>
          </div>
        </div>
      </section>

      <div className="container-x space-y-14 pb-14 md:space-y-16 md:pb-16">
        <CategorySection {...sindh} layout="lead" />
        <CategorySection {...politics} layout="grid" />
      </div>

      <VideoSection videos={videos} />

      <div className="container-x space-y-14 py-14 md:space-y-16 md:py-16">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-10">
          <CategorySection {...pakistan} layout="column" />
          <CategorySection {...karachi} layout="column" />
        </div>
        <CategorySection {...districts} layout="grid" />
      </div>

      <OpinionSection items={opinionItems} />

      <div className="container-x space-y-14 py-14 md:space-y-16 md:py-16">
        <CategorySection {...culture} layout="lead" />
        <div className="grid gap-12 lg:grid-cols-3 lg:gap-8">
          <CategorySection {...world} layout="column" />
          <CategorySection {...society} layout="column" />
          <CategorySection {...education} layout="column" />
        </div>
      </div>

      <div className="border-t border-line bg-mist/50">
        <PublicVoice items={voices} />
      </div>

      <Newsletter />
    </>
  );
}
