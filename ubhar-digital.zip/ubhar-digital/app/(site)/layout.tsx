import type { ReactNode } from 'react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { BreakingNewsTicker } from '@/components/BreakingNewsTicker';
import { SearchModal } from '@/components/SearchModal';
import { JsonLd } from '@/components/JsonLd';
import { getBreakingNews } from '@/lib/content';
import { organizationJsonLd, websiteJsonLd } from '@/lib/seo';

export default async function SiteLayout({ children }: { children: ReactNode }) {
  const breaking = await getBreakingNews();
  return (
    <>
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:start-2 focus:z-[100] focus:bg-brand focus:px-4 focus:py-2 focus:text-white">
        مکيه مواد ڏانهن وڃو
      </a>
      <Header />
      <BreakingNewsTicker items={breaking} />
      <main id="main">{children}</main>
      <Footer />
      <SearchModal />
      <JsonLd data={organizationJsonLd()} />
      <JsonLd data={websiteJsonLd()} />
    </>
  );
}
