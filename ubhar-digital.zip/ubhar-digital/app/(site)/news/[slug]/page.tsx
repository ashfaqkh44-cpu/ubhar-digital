import type { Metadata } from 'next';
import Image from 'next/image';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { CategoryBadge } from '@/components/CategoryBadge';
import { AuthorAvatar } from '@/components/OpinionSection';
import { SocialShare } from '@/components/SocialShare';
import { NewsCard } from '@/components/NewsCard';
import { SectionHeading } from '@/components/SectionHeading';
import { Sidebar } from '@/components/Sidebar';
import { VideoEmbed } from '@/components/VideoEmbed';
import { JsonLd } from '@/components/JsonLd';
import { Icon } from '@/components/Icon';
import { getAllArticles, getArticle, getAuthor, getLatest, getMostRead, getRelated, wordCount } from '@/lib/content';
import { getCategory } from '@/lib/categories';
import { formatDateWithDay, formatDateTime, formatTime, readingMinutes } from '@/lib/date';
import { absoluteUrl, articleMetadata, breadcrumbJsonLd, newsArticleJsonLd } from '@/lib/seo';
import { site } from '@/lib/site';

type Props = { params: Promise<{ slug: string }> };

export const revalidate = 300;

export async function generateStaticParams() {
  return (await getAllArticles()).map((a) => ({ slug: a.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const a = await getArticle(slug);
  if (!a) return { title: 'خبر نه ملي' };
  return articleMetadata(a, await getAuthor(a.authorId), getCategory(a.category));
}

export default async function ArticlePage({ params }: Props) {
  const { slug } = await params;
  const article = await getArticle(slug);
  if (!article) notFound();

  const [author, related, mostRead, latest] = await Promise.all([
    getAuthor(article.authorId),
    getRelated(article, 4),
    getMostRead(5),
    getLatest(4, [article.slug]),
  ]);
  const category = getCategory(article.category)!;
  const url = absoluteUrl(`/news/${article.slug}`);
  const crumbs = [
    { name: 'هوم', href: '/' },
    { name: category.name, href: `/category/${category.slug}` },
    { name: article.title, href: `/news/${article.slug}` },
  ];

  return (
    <>
      <JsonLd data={newsArticleJsonLd(article, author, category)} />
      <JsonLd data={breadcrumbJsonLd(crumbs)} />

      <div className="container-x py-6 md:py-10">
        <Breadcrumbs items={crumbs} />

        <div className="mt-6 grid gap-10 lg:grid-cols-12">
          <article className="min-w-0 lg:col-span-8">
            <header>
              <div className="flex flex-wrap items-center gap-3">
                <CategoryBadge slug={article.category} />
                {article.location && (
                  <span className="inline-flex items-center gap-1 text-sm font-semibold text-slate">
                    <Icon name="pin" size={14} className="text-brand" />
                    {article.location}
                  </span>
                )}
                {article.voiceType && <span className="slant bg-ink py-0.5 text-[13px] font-bold text-white">{article.voiceType}</span>}
              </div>
              <h1 className="mt-4 text-[1.85rem] leading-[1.55] font-black md:text-[2.5rem] lg:text-[2.75rem]">{article.title}</h1>
              <p className="mt-4 border-s-4 border-brand ps-4 font-naskh text-lg leading-9 text-slate md:text-xl md:leading-10">{article.summary}</p>

              <div className="mt-6 flex flex-col gap-4 border-y border-line py-4 md:flex-row md:items-center md:justify-between">
                <div className="flex items-center gap-3">
                  <AuthorAvatar author={author} size={46} />
                  <div className="leading-relaxed">
                    <p className="font-bold">{author.name}</p>
                    <p className="flex flex-wrap gap-x-3 text-[13px] text-steel">
                      <span>
                        شايع: <time dateTime={article.publishedAt}>{formatDateTime(article.publishedAt)}</time>
                      </span>
                      {article.updatedAt && (
                        <span>
                          تازه ڪاري: <time dateTime={article.updatedAt}>{formatTime(article.updatedAt)}</time>
                        </span>
                      )}
                      <span>{readingMinutes(wordCount(article))} منٽ پڙهڻ</span>
                    </p>
                  </div>
                </div>
                <SocialShare url={url} title={article.title} />
              </div>
            </header>

            <figure className="mt-6">
              {article.video ? (
                <VideoEmbed video={article.video} poster={article.image} title={article.title} />
              ) : (
                <div className="relative aspect-video overflow-hidden bg-graphite">
                  <Image src={article.image} alt={article.imageAlt} fill priority sizes="(min-width:1024px) 820px, 100vw" className="object-cover" />
                </div>
              )}
              {article.imageCaption && <figcaption className="mt-2 border-s-2 border-brand ps-2 text-sm text-steel">{article.imageCaption}</figcaption>}
            </figure>

            {site.showSampleNotice && article.sample && (
              <p className="mt-6 flex items-start gap-2 bg-brand-soft p-3 text-sm text-brand-dark">
                <Icon name="zap" size={16} className="mt-1 shrink-0" />
                نوٽ: هي نموني جي خبر آهي، جيڪا ويب سائيٽ جي ڊولپمينٽ پريويو لاءِ لکي وئي آهي. اصل خبرون CMS/ايڊمن ذريعي شايع ڪيون وينديون.
              </p>
            )}

            <div className="prose-sd mx-auto mt-8 max-w-[44rem]">
              {article.body.map((block, i) => {
                if (typeof block === 'string') return <p key={i}>{block}</p>;
                if (block.type === 'h2') return <h2 key={i}>{block.text}</h2>;
                return (
                  <blockquote key={i}>
                    “{block.text}”{block.cite && <cite>— {block.cite}</cite>}
                  </blockquote>
                );
              })}
            </div>

            {article.tags && article.tags.length > 0 && (
              <div className="mx-auto mt-8 flex max-w-[44rem] flex-wrap items-center gap-2">
                <span className="text-sm font-bold text-slate">ٽيگ:</span>
                {article.tags.map((t) => (
                  <Link key={t} href={`/search?q=${encodeURIComponent(t)}`} className="border border-line px-3 py-1 text-sm hover:border-brand hover:text-brand">
                    {t}
                  </Link>
                ))}
              </div>
            )}

            <div className="mx-auto mt-8 max-w-[44rem] border-y-2 border-ink py-5">
              <SocialShare url={url} title={article.title} />
            </div>

            {/* Comments — placeholder until a comments service is connected */}
            <section aria-labelledby="comments-title" className="mx-auto mt-10 max-w-[44rem]">
              <h2 id="comments-title" className="flex items-center gap-2 text-xl">
                <Icon name="message" size={22} className="text-brand" />
                تبصرا
              </h2>
              <div className="mt-4 border border-dashed border-line bg-mist p-6 text-center">
                <p className="font-bold">تبصرن جو سلسلو جلد شروع ٿيندو.</p>
                <p className="mt-1 text-sm text-steel">
                  تيستائين پنهنجي راءِ{' '}
                  <Link href="/contact?subject=general" className="font-bold text-brand underline">
                    رابطي فارم
                  </Link>{' '}
                  يا سوشل ميڊيا ذريعي موڪليو.
                </p>
              </div>
            </section>

            <p className="sr-only">شايع ٿيل: {formatDateWithDay(article.publishedAt)}</p>
          </article>

          <div className="lg:col-span-4">
            <Sidebar mostRead={mostRead} latest={latest} />
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <section aria-labelledby="related-title" className="border-t border-line bg-mist/60 py-12">
          <div className="container-x">
            <SectionHeading id="related-title" title="لاڳاپيل خبرون" href={`/category/${category.slug}`} />
            <div className="grid gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
              {related.map((a) => (
                <NewsCard key={a.slug} article={a} showSummary={false} />
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  );
}
