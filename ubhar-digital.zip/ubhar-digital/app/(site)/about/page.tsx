import Link from 'next/link';
import { PageHero } from '@/components/PageHero';
import { Logo } from '@/components/Logo';
import { Icon, type IconName } from '@/components/Icon';
import { SocialLinks } from '@/components/SocialLinks';
import { pageMetadata } from '@/lib/seo';
import { site } from '@/lib/site';

export const metadata = pageMetadata({
  title: 'اُڀار بابت — About UBHAR',
  description: 'اُڀار ڊجيٽل هڪ آزاد ڊجيٽل ميڊيا پليٽ فارم آهي جيڪو خبرن، عوامي شعور ۽ ڪميونٽي جي آواز لاءِ وقف آهي.',
  path: '/about',
});

const values: { icon: IconName; title: string; text: string }[] = [
  { icon: 'zap', title: 'خبر', text: 'تيز، پر تصديق ٿيل. اسان لاءِ درستگي رفتار کان وڌيڪ اهم آهي.' },
  { icon: 'eye', title: 'نظر', text: 'واقعن جي پسمنظر، تجزيي ۽ مختلف نقطه نظر سان ڀرپور ڪوريج.' },
  { icon: 'megaphone', title: 'آواز', text: 'عام ماڻهوءَ جو مسئلو، سوال ۽ ڪهاڻي — اسان جي ترجيح.' },
];

export default function AboutPage() {
  return (
    <>
      <PageHero title="اُڀار بابت" eyebrow="About UBHAR" subtitle={site.slogan} path="/about" />
      <div className="container-x grid gap-12 py-12 md:py-16 lg:grid-cols-12">
        <div className="prose-sd lg:col-span-7">
          <p>
            <strong>اُڀار ڊجيٽل</strong> هڪ آزاد ڊجيٽل ميڊيا پليٽ فارم آهي، جيڪو خبرن، عوامي شعور، ڪميونٽي جي آوازن، سماجي مسئلن، سياست، ثقافت، تعليم ۽ سنڌ توڙي دنيا ۾ ٿيندڙ اهم واقعن لاءِ وقف آهي.
          </p>
          <p>اسان جو مشن ڊجيٽل پڙهندڙن ۽ ڏسندڙن تائين معلومات، نقطه نظر ۽ عوام جو آواز پهچائڻ آهي — پنهنجي ٻوليءَ ۾، پنهنجي سڃاڻپ سان.</p>
          <h2>اسان جو واعدو</h2>
          <p>اسان ذميوار صحافت، تصديق، توازن ۽ شفافيت تي يقين رکون ٿا. هر خبر ۾ سڀني لاڳاپيل ڌرين جو موقف شامل ڪرڻ جي ڪوشش ڪريون ٿا ۽ غلطي جي صورت ۾ کليل دل سان درستگي شايع ڪريون ٿا.</p>
          <blockquote>
            خبر، نظر ۽ آواز عوام جو.
            <cite>— اُڀار ڊجيٽل</cite>
          </blockquote>
          <p>
            UBHAR Digital is an independent digital media platform dedicated to news, public awareness, community voices, social issues, politics, culture, education, and developments across Sindh and beyond. Its mission is to bring information,
            perspective, and the public voice to digital audiences.
          </p>
        </div>
        <aside className="lg:col-span-5">
          <div className="relative overflow-hidden bg-ink p-8 text-white">
            <div aria-hidden className="dots absolute inset-0 text-white/[0.06]" />
            <div className="relative flex flex-col items-center text-center">
              <Logo variant="tagline" height={200} link={false} />
              <p className="mt-6 font-display text-xl font-extrabold">{site.sloganShort}</p>
              <SocialLinks size={18} boxed className="mt-6 flex-wrap justify-center gap-2" itemClassName="text-white" />
            </div>
          </div>
          <ul className="mt-6 space-y-4">
            {values.map((v) => (
              <li key={v.title} className="flex gap-4 border-s-4 border-brand bg-mist p-5">
                <Icon name={v.icon} size={26} className="shrink-0 text-brand" />
                <div>
                  <h3 className="text-lg">{v.title}</h3>
                  <p className="mt-1 font-naskh leading-8 text-slate">{v.text}</p>
                </div>
              </li>
            ))}
          </ul>
          <Link href="/contact" className="mt-6 flex h-12 items-center justify-center gap-2 bg-brand font-bold text-white hover:bg-brand-dark">
            اسان سان رابطو ڪريو <Icon name="arrowLeft" size={16} />
          </Link>
        </aside>
      </div>
    </>
  );
}
