import type { Metadata } from 'next';
import Link from 'next/link';
import { NewsCard } from '@/components/NewsCard';
import { Icon } from '@/components/Icon';
import { search } from '@/lib/content';

type Props = { searchParams: Promise<{ q?: string }> };

export async function generateMetadata({ searchParams }: Props): Promise<Metadata> {
  const { q } = await searchParams;
  return { title: q ? `“${q}” — ڳولا` : 'ڳولا', robots: { index: false, follow: true } };
}

const SUGGESTIONS = ['سنڌ', 'ڪراچي', 'سياست', 'تعليم', 'پاڻي', 'ثقافت', 'پانی', 'Karachi', 'Education'];

export default async function SearchPage({ searchParams }: Props) {
  const { q = '' } = await searchParams;
  const query = q.trim().slice(0, 100);
  const results = query ? await search(query, 40) : [];

  return (
    <div className="container-x py-10 md:py-14">
      <h1 className="text-[2rem] font-black md:text-[2.6rem]">خبرون ڳوليو</h1>
      <p className="mt-1 text-steel">سنڌي، اردو يا انگريزي لفظن ۾ ڳولا ڪريو.</p>

      <form action="/search" role="search" className="mt-6 flex max-w-3xl border-2 border-ink focus-within:border-brand">
        <label htmlFor="search-page-input" className="sr-only">
          ڳولا
        </label>
        <input
          id="search-page-input"
          name="q"
          type="search"
          defaultValue={query}
          placeholder="مثال: ڪراچي، تعليم، Karachi، پانی..."
          className="h-14 min-w-0 flex-1 bg-white px-4 font-display text-lg outline-none"
        />
        <button type="submit" className="inline-flex h-14 items-center gap-2 bg-brand px-6 font-bold text-white hover:bg-brand-dark">
          <Icon name="search" size={20} />
          <span className="max-sm:sr-only">ڳوليو</span>
        </button>
      </form>

      <div className="mt-4 flex flex-wrap gap-2">
        {SUGGESTIONS.map((s) => (
          <Link key={s} href={`/search?q=${encodeURIComponent(s)}`} className="border border-line px-3 py-1 text-sm font-semibold hover:border-brand hover:text-brand">
            {s}
          </Link>
        ))}
      </div>

      <div className="mt-10">
        {query && (
          <p className="mb-6 border-b border-line pb-3 font-bold" role="status">
            “{query}” لاءِ <span className="text-brand">{results.length}</span> نتيجا مليا
          </p>
        )}

        {query && results.length === 0 && (
          <div className="mx-auto max-w-md py-16 text-center">
            <div className="mx-auto flex size-20 items-center justify-center rounded-full bg-mist text-steel">
              <Icon name="search" size={34} />
            </div>
            <h2 className="mt-5 text-2xl">ڪو به نتيجو نه مليو</h2>
            <p className="mt-2 text-steel">ٻيا لفظ آزمايو، اسپيلنگ چيڪ ڪريو يا مٿي ڏنل موضوعن مان ڪو چونڊيو.</p>
            <Link href="/category/latest" className="mt-6 inline-flex h-11 items-center gap-2 bg-ink px-5 font-bold text-white hover:bg-brand">
              تازيون خبرون ڏسو <Icon name="arrowLeft" size={16} />
            </Link>
          </div>
        )}

        {!query && <p className="py-10 text-center text-steel">ڳولا شروع ڪرڻ لاءِ مٿي ڪو لفظ لکو.</p>}

        {results.length > 0 && (
          <div className="max-w-4xl divide-y divide-line">
            {results.map(({ article }) => (
              <NewsCard key={article.slug} article={article} variant="horizontal" headingLevel={2} className="py-6 first:pt-0" />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
