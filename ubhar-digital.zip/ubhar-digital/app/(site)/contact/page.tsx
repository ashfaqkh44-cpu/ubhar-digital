import { PageHero } from '@/components/PageHero';
import { ContactForm, CONTACT_SUBJECTS } from '@/components/ContactForm';
import { Icon } from '@/components/Icon';
import { SocialLinks } from '@/components/SocialLinks';
import { pageMetadata } from '@/lib/seo';
import { site } from '@/lib/site';

export const metadata = pageMetadata({
  title: 'رابطو — Contact',
  description: 'اُڀار ڊجيٽل سان رابطو ڪريو — خبر، ٽپ، عوامي مسئلو، درستگي يا اشتهار لاءِ.',
  path: '/contact',
});

type Props = { searchParams: Promise<{ subject?: string }> };

export default async function ContactPage({ searchParams }: Props) {
  const { subject } = await searchParams;
  const defaultSubject = CONTACT_SUBJECTS.some((s) => s.value === subject) ? subject! : 'general';
  return (
    <>
      <PageHero title="اسان سان رابطو ڪريو" eyebrow="Contact" subtitle="خبر، ٽپ، عوامي مسئلو، درستگي يا ڪاروباري رابطو — اسان توهان جي ڳالهه ٻڌڻ لاءِ تيار آهيون." path="/contact" />
      <div className="container-x grid gap-12 py-12 md:py-16 lg:grid-cols-12">
        <div className="lg:col-span-8">
          <h2 className="mb-6 text-2xl">پيغام موڪليو</h2>
          <ContactForm defaultSubject={defaultSubject} />
          <p className="mt-4 text-xs text-steel">نوٽ: فارم جي تصديق ڪم ڪري ٿي؛ پيغام پهچائڻ لاءِ اي ميل/ڊيٽابيس سروس اڃا ڳنڍڻي آهي (README ڏسو).</p>
        </div>
        <aside className="space-y-4 lg:col-span-4">
          <a href={`https://wa.me/${site.contact.whatsapp}`} target="_blank" rel="noopener noreferrer" className="group flex items-center gap-4 bg-ink p-5 text-white hover:bg-charcoal">
            <span className="flex size-12 items-center justify-center bg-brand">
              <Icon name="whatsapp" size={24} />
            </span>
            <span>
              <span className="block font-bold">واٽس ايپ تي رابطو</span>
              <span className="ltr block text-white/60">{site.contact.phone}</span>
            </span>
          </a>
          <a href={`mailto:${site.contact.email}`} className="flex items-center gap-4 border border-line p-5 hover:border-brand">
            <Icon name="mail" size={24} className="text-brand" />
            <span>
              <span className="block font-bold">اي ميل</span>
              <span className="ltr block text-slate">{site.contact.email}</span>
            </span>
          </a>
          <div className="flex items-center gap-4 border border-line p-5">
            <Icon name="pin" size={24} className="text-brand" />
            <span>
              <span className="block font-bold">پتو</span>
              <span className="block text-slate">{site.contact.address}</span>
            </span>
          </div>
          <div className="bg-mist p-5">
            <p className="mb-3 font-bold">سوشل ميڊيا</p>
            <SocialLinks size={18} boxed className="flex-wrap gap-2" itemClassName="text-ink" />
          </div>
        </aside>
      </div>
    </>
  );
}
