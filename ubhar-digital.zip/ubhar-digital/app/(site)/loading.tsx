/** Skeleton shown while a page streams in — same geometry as the real layout to avoid layout shift. */
export default function Loading() {
  return (
    <div className="container-x animate-pulse py-8" aria-busy="true" aria-label="لوڊ ٿي رهيو آهي">
      <div className="grid gap-6 lg:grid-cols-12">
        <div className="aspect-video bg-mist lg:col-span-8" />
        <div className="space-y-5 lg:col-span-4">
          {[0, 1, 2].map((i) => (
            <div key={i} className="flex gap-4">
              <div className="aspect-[4/3] w-36 bg-mist" />
              <div className="flex-1 space-y-2 pt-2">
                <div className="h-4 bg-mist" />
                <div className="h-4 w-2/3 bg-mist" />
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {[0, 1, 2, 3].map((i) => (
          <div key={i}>
            <div className="aspect-video bg-mist" />
            <div className="mt-4 h-4 bg-mist" />
            <div className="mt-2 h-4 w-3/4 bg-mist" />
          </div>
        ))}
      </div>
    </div>
  );
}
