import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { NewsCard } from '@/components/NewsCard';
import { VideoNewsCard } from '@/components/VideoNewsCard';
import { OpinionCard } from '@/components/OpinionSection';
import { PublicVoiceCard } from '@/components/PublicVoice';
import { Pagination } from '@/components/Pagination';
import { Sidebar } from '@/components/Sidebar';
import { JsonLd } from '@/components/JsonLd';
import { categories, getCategory } from '@/lib/categories';
import { getArticlesByCategory, getAuthor, getMostRead } from '@/lib/content';
import { breadcrumbJsonLd, pageMetadata } from '@/lib/seo';
import type { CategorySlug } from '@/lib/types';

type Props = { params: Promise<{ slug: string }>; searchParams: Promise<{ page?: string }> };

const PER_PAGE = 8;

export function generateStaticParams() {
  return [{ slug: 'latest' }, ...categories.map((c) => ({ slug: c.slug }))];
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const cat = getCategory(slug);
  if (!cat) return { title: 'سيڪشن نه مليو' };
  return pageMetadata({ title: `${cat.name} — ${cat.nameEn}`, description: cat.description, path: `/category/${cat.slug}` });
}

export default async function CategoryPage({ params, searchParams }: Props) {
  const { slug } = await params;
  const { page: pageParam } = await searchParams;
  const category = getCategory(slug);
  if (!category) notFound();

  const all = await getArticlesByCategory(slug as CategorySlug | 'latest');
  const [featured, ...rest] = all;
  const totalPages = Math.max(1, Math.ceil(rest.length / PER_PAGE));
  const page = Math.min(Math.max(1, Number(pageParam) || 1), totalPages);
  const list = rest.slice((page - 1) * PER_PAGE, page * PER_PAGE);
  const mostRead = await getMostRead(5);
  const isVideo = slug === 'videos';
  const isOpinion = slug === 'opinion';
  const isVoice = slug === 'public-voice';
  const opinionAuthors = isOpinion ? await Promise.all(list.map((a) => getAuthor(a.authorId))) : [];

  const crumbs = [
    { name: 'هوم', href: '/' },
    { name: category.name, href: `/category/${category.slug}` },
  ];

  return (
    <>
      <JsonLd data={breadcrumbJsonLd(crumbs)} />
      <header className="relative overflow-hidden bg-ink text-white">
        <div aria-hidden className="absolute -bottom-32 -end-24 size-80 rounded-full bg-brand md:size-96" />
        <div aria-hidden className="absolute -bottom-44 -end-36 size-[26rem] rounded-full border border-brand/50 md:size-[30rem]" />
        <div aria-hidden className="dots absolute inset-y-0 start-0 w-1/2 text-white/[0.07]" />
        <div className="container-x relative py-10 md:py-14">
          <Breadcrumbs items={crumbs} dark />
          <h1 className="mt-4 flex items-center gap-4 text-[2.4rem] leading-tight font-black md:text-[3.4rem]">
            <span className="h-12 w-2 bg-brand md:h-16" aria-hidden />
            {category.name}
          </h1>
          <p className="mt-3 max-w-2xl font-naskh text-lg leading-9 text-white/70">{category.description}</p>
          <p className="ltr mt-2 text-end text-sm tracking-[0.25em] text-white/40 uppercase md:text-start">{category.nameEn}</p>
        </div>
      </header>

      <div className="container-x py-10 md:py-12">
        {!featured ? (
          <p className="py-16 text-center text-lg text-steel">هن سيڪشن ۾ اڃا ڪا خبر شايع ناهي ٿي.</p>
        ) : (
          <div className="grid gap-10 lg:grid-cols-12">
            <div className="min-w-0 lg:col-span-8">
              {page === 1 &&
                (isVideo ? (
                  <div className="bg-ink p-4 md:p-6">
                    <VideoNewsCard article={featured} featured />
                  </div>
                ) : (
                  <NewsCard article={featured} variant="overlay" priority headingLevel={2} />
                ))}

              {isVideo ? (
                <div className="mt-8 grid gap-6 bg-ink p-4 sm:grid-cols-2 md:p-6">
                  {list.map((a) => (
                    <VideoNewsCard key={a.slug} article={a} />
                  ))}
                </div>
              ) : isOpinion ? (
                <div className="mt-8 grid gap-6 sm:grid-cols-2">
                  {list.map((a, i) => (
                    <OpinionCard key={a.slug} article={a} author={opinionAuthors[i]} />
                  ))}
                </div>
              ) : isVoice ? (
                <div className="mt-8 grid gap-5 sm:grid-cols-2">
                  {list.map((a) => (
                    <PublicVoiceCard key={a.slug} article={a} />
                  ))}
                </div>
              ) : (
                <div className="mt-8 divide-y divide-line">
                  {list.map((a) => (
                    <NewsCard key={a.slug} article={a} variant="horizontal" showCategory={slug === 'latest'} headingLevel={2} className="py-6 first:pt-0" />
                  ))}
                </div>
              )}

              {list.length === 0 && page === 1 && <p className="mt-8 text-steel">وڌيڪ خبرون جلد شامل ڪيون وينديون.</p>}
              <Pagination current={page} total={totalPages} basePath={`/category/${category.slug}`} />
            </div>
            <div className="lg:col-span-4">
              <Sidebar mostRead={mostRead} />
            </div>
          </div>
        )}
      </div>
    </>
  );
}
