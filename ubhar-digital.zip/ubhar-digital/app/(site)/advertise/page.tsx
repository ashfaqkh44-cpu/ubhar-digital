import Link from 'next/link';
import { PageHero } from '@/components/PageHero';
import { Icon, type IconName } from '@/components/Icon';
import { pageMetadata } from '@/lib/seo';
import { site } from '@/lib/site';

export const metadata = pageMetadata({
  title: 'اُڀار تي اشتهار — Advertise With UBHAR',
  description: 'ڊجيٽل اشتهار، اسپانسرڊ پوسٽون، وڊيو پروموشن ۽ عوامي شعور جون مهمون — اُڀار ڊجيٽل سان.',
  path: '/advertise',
});

const services: { icon: IconName; title: string; en: string; text: string }[] = [
  { icon: 'globe', title: 'ڊجيٽل اشتهار', en: 'Digital advertising', text: 'ويب سائيٽ تي بينر ۽ ڊسپلي اشتهار، موبائل لاءِ بهتر.' },
  { icon: 'edit', title: 'اسپانسرڊ پوسٽون', en: 'Sponsored posts', text: 'واضح ليبل سان اسپانسرڊ مواد، اسان جي ادارتي معيار موجب.' },
  { icon: 'video', title: 'وڊيو پروموشن', en: 'Video promotion', text: 'برانڊ لاءِ مختصر وڊيوز ۽ اسان جي وڊيو نيٽ ورڪ تي پروموشن.' },
  { icon: 'star', title: 'برانڊ پروموشن', en: 'Brand promotion', text: 'سنڌي ڳالهائيندڙ آڊينس تائين توهان جي برانڊ جي سڃاڻپ.' },
  { icon: 'trending', title: 'سوشل ميڊيا مهمون', en: 'Social media campaigns', text: 'فيس بڪ، يوٽيوب، انسٽاگرام ۽ ٽڪ ٽاڪ تي ٽارگيٽ ٿيل مهمون.' },
  { icon: 'pin', title: 'ڪاروباري اشتهار', en: 'Business advertising', text: 'مقامي ڪاروبارن لاءِ سستا ۽ اثرائتا پيڪيج.' },
  { icon: 'megaphone', title: 'عوامي شعور جون مهمون', en: 'Public awareness campaigns', text: 'صحت، تعليم ۽ سماجي ڀلائي جي پيغامن لاءِ ڀائيواري.' },
];

export default function AdvertisePage() {
  return (
    <>
      <PageHero title="اُڀار تي اشتهار ڏيو" eyebrow="Advertise With UBHAR" subtitle="سنڌ ۽ دنيا ڀر ۾ سنڌي ڳالهائيندڙ ڊجيٽل آڊينس تائين پنهنجو پيغام پهچايو." path="/advertise" />
      <div className="container-x py-12 md:py-16">
        <h2 className="text-2xl md:text-3xl">اسان جون ميڊيا سروسز</h2>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((s) => (
            <div key={s.title} className="reveal group border border-line p-6 transition-colors hover:border-ink">
              <span className="flex size-12 items-center justify-center bg-ink text-white transition-colors group-hover:bg-brand">
                <Icon name={s.icon} size={22} />
              </span>
              <h3 className="mt-4 text-lg">{s.title}</h3>
              <p className="ltr text-end text-xs text-steel">{s.en}</p>
              <p className="mt-2 font-naskh leading-8 text-slate">{s.text}</p>
            </div>
          ))}
          <div className="flex flex-col justify-between bg-brand p-6 text-white">
            <p className="font-display text-xl font-extrabold">پنهنجي ضرورت موجب پيڪيج چاهيو ٿا؟</p>
            <Link href="/contact?subject=advertising" className="mt-4 inline-flex h-11 items-center justify-center gap-2 bg-ink font-bold hover:bg-charcoal">
              رابطو ڪريو <Icon name="arrowLeft" size={16} />
            </Link>
          </div>
        </div>

        <div className="relative mt-14 overflow-hidden bg-ink p-8 text-white md:p-12">
          <div aria-hidden className="absolute -end-20 -bottom-24 size-72 rounded-full bg-brand" />
          <div className="relative max-w-2xl">
            <h2 className="text-2xl md:text-3xl">اچو، گڏجي ڪم ڪريون</h2>
            <p className="mt-3 font-naskh text-lg leading-9 text-white/75">ميڊيا ڪٽ، ريٽ ڪارڊ ۽ آڊينس جي تفصيل لاءِ اسان جي ٽيم سان رابطو ڪريو.</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/contact?subject=advertising" className="inline-flex h-12 items-center gap-2 bg-brand px-6 font-bold hover:bg-brand-dark">
                اشتهار لاءِ رابطو <Icon name="arrowLeft" size={16} />
              </Link>
              <a href={`mailto:${site.contact.email}?subject=Advertising`} className="ltr inline-flex h-12 items-center gap-2 border border-white/30 px-5 font-bold hover:border-white">
                {site.contact.email}
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
