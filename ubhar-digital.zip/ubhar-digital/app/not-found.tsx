import { NotFoundContent } from '@/components/NotFoundContent';
import { Logo } from '@/components/Logo';

export default function NotFound() {
  return (
    <>
      <header className="border-b-[3px] border-brand bg-ink">
        <div className="container-x flex h-20 items-center">
          <Logo height={60} />
        </div>
      </header>
      <main>
        <NotFoundContent />
      </main>
    </>
  );
}
