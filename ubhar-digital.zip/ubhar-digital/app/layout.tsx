import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import { Inter, Noto_Naskh_Arabic, Noto_Sans_Arabic } from 'next/font/google';
import './globals.css';
import { site } from '@/lib/site';

/* Headlines & UI */
const notoSans = Noto_Sans_Arabic({ subsets: ['arabic'], variable: '--font-ui', display: 'swap' });
/* Article body — Naskh is the most readable style for long Sindhi text */
const notoNaskh = Noto_Naskh_Arabic({ subsets: ['arabic'], variable: '--font-body', display: 'swap' });
/* English words, numbers, URLs */
const inter = Inter({ subsets: ['latin'], variable: '--font-latin', display: 'swap' });

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: `${site.nameSd} | ${site.name} — ${site.sloganShort}`, template: `%s | ${site.nameSd}` },
  description: site.description,
  applicationName: site.name,
  keywords: ['اُڀار', 'سنڌي خبرون', 'سنڌ', 'ڪراچي', 'سياست', 'UBHAR', 'Sindhi news', 'Sindh news'],
  openGraph: {
    type: 'website',
    locale: site.locale,
    siteName: site.nameSd,
    title: site.nameSd,
    description: site.description,
    images: [{ url: site.ogImage, width: 1200, height: 630, alt: site.name }],
  },
  twitter: { card: 'summary_large_image', site: '@UBHARdigital', images: [site.ogImage] },
  alternates: { canonical: '/' },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = {
  themeColor: '#0B0B0F',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="sd" dir="rtl" className={`${notoSans.variable} ${notoNaskh.variable} ${inter.variable}`}>
      <body className="min-h-dvh overflow-x-hidden">{children}</body>
    </html>
  );
}
