import { NextResponse } from 'next/server';
import { search } from '@/lib/content';
import { categoryName } from '@/lib/categories';
import type { SearchHit } from '@/lib/types';


export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const q = (searchParams.get('q') ?? '').slice(0, 100);
  const limit = Math.min(20, Math.max(1, Number(searchParams.get('limit')) || 10));
  const results: SearchHit[] = (await search(q, limit)).map(({ article: a }) => ({
    slug: a.slug,
    title: a.title,
    summary: a.summary,
    image: a.image,
    category: a.category,
    categoryName: categoryName(a.category),
    publishedAt: a.publishedAt,
  }));
  return NextResponse.json({ query: q, results }, { headers: { 'Cache-Control': 'public, s-maxage=60, stale-while-revalidate=300' } });
}
