import { NextResponse } from 'next/server';

/**
 * Newsletter signup — PLACEHOLDER.
 * Validates the email and returns success, but does not store it yet.
 * Connect a provider (Mailchimp, Brevo, Resend, ConvertKit, or a Supabase table) here.
 */
export async function POST(request: Request) {
  let email = '';
  try {
    ({ email = '' } = (await request.json()) as { email?: string });
  } catch {
    return NextResponse.json({ ok: false, message: 'غلط درخواست.' }, { status: 400 });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim()) || email.length > 200) {
    return NextResponse.json({ ok: false, message: 'مهرباني ڪري صحيح اي ميل ايڊريس لکو.' }, { status: 422 });
  }
  // TODO: await subscribeToProvider(email)
  return NextResponse.json({
    ok: true,
    placeholder: true,
    message: 'شڪريه! (ڊيمو: نيوز ليٽر سروس اڃا ڳنڍيل ناهي — اي ميل محفوظ نه ڪئي وئي.)',
  });
}
