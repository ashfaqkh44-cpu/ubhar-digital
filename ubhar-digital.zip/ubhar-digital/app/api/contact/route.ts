import { NextResponse } from 'next/server';

/**
 * Contact form — PLACEHOLDER.
 * Validates input server-side. To deliver messages, send them by email (e.g. Resend)
 * or insert into a database table (e.g. Supabase) where the comment says TODO.
 */
export async function POST(request: Request) {
  let body: Record<string, string> = {};
  try {
    body = (await request.json()) as Record<string, string>;
  } catch {
    return NextResponse.json({ ok: false, message: 'غلط درخواست.' }, { status: 400 });
  }
  const name = String(body.name ?? '').trim();
  const email = String(body.email ?? '').trim();
  const message = String(body.message ?? '').trim();
  if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || message.length < 15 || message.length > 5000) {
    return NextResponse.json({ ok: false, message: 'مهرباني ڪري سمورا گهربل خانا صحيح ڀريو.' }, { status: 422 });
  }
  // TODO: await sendEmail({ to: 'info@ubhar.digital', ... }) or save to database
  return NextResponse.json({
    ok: true,
    placeholder: true,
    message: 'توهان جو پيغام فارم ذريعي درست طور موڪليو ويو. (ڊيمو: اي ميل/ڊيٽابيس اڃا ڳنڍيل ناهي.)',
  });
}
