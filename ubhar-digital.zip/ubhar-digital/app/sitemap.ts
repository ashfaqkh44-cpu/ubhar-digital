import type { MetadataRoute } from 'next';
import { getAllArticles } from '@/lib/content';
import { categories } from '@/lib/categories';
import { site } from '@/lib/site';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const articles = await getAllArticles();
  const now = new Date();
  const staticPages = ['', '/about', '/contact', '/advertise', '/editorial-policy', '/privacy-policy', '/terms'].map((p) => ({
    url: `${site.url}${p}`,
    lastModified: now,
    changeFrequency: p === '' ? ('hourly' as const) : ('monthly' as const),
    priority: p === '' ? 1 : 0.4,
  }));
  const categoryPages = ['latest', ...categories.map((c) => c.slug)].map((slug) => ({
    url: `${site.url}/category/${slug}`,
    lastModified: now,
    changeFrequency: 'hourly' as const,
    priority: 0.8,
  }));
  const articlePages = articles.map((a) => ({
    url: `${site.url}/news/${a.slug}`,
    lastModified: new Date(a.updatedAt ?? a.publishedAt),
    changeFrequency: 'daily' as const,
    priority: 0.7,
    images: [`${site.url}${a.image}`],
  }));
  return [...staticPages, ...categoryPages, ...articlePages];
}
