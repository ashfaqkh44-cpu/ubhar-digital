/**
 * Sindhi date helpers. All formatting is done in the Asia/Karachi timezone so
 * server and client render the same text (no hydration mismatches).
 */

export const SINDHI_MONTHS = [
  'جنوري', 'فيبروري', 'مارچ', 'اپريل', 'مئي', 'جون',
  'جولاءِ', 'آگسٽ', 'سيپٽمبر', 'آڪٽوبر', 'نومبر', 'ڊسمبر',
];

/** Sunday-first, matching Date.getDay() */
export const SINDHI_WEEKDAYS = ['آچر', 'سومر', 'اڱارو', 'اربع', 'خميس', 'جمعو', 'ڇنڇر'];

export const HIJRI_MONTHS = [
  'محرم', 'صفر', 'ربيع الاول', 'ربيع الثاني', 'جمادي الاول', 'جمادي الثاني',
  'رجب', 'شعبان', 'رمضان', 'شوال', 'ذوالقعد', 'ذوالحج',
];

const TZ = 'Asia/Karachi';

interface Parts {
  year: number;
  month: number; // 1-12
  day: number;
  weekday: number; // 0 = Sunday
  hour: number;
  minute: number;
}

function parts(input: string | Date): Parts {
  const d = typeof input === 'string' ? new Date(input) : input;
  const fmt = new Intl.DateTimeFormat('en-US', {
    timeZone: TZ,
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
    weekday: 'short',
    hour: 'numeric',
    minute: 'numeric',
    hour12: false,
  });
  const p: Record<string, string> = {};
  for (const x of fmt.formatToParts(d)) p[x.type] = x.value;
  const wd = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(p.weekday);
  return {
    year: Number(p.year),
    month: Number(p.month),
    day: Number(p.day),
    weekday: wd,
    hour: Number(p.hour) % 24,
    minute: Number(p.minute),
  };
}

const pad = (n: number) => String(n).padStart(2, '0');

/** "18 نومبر 2026" */
export function formatDate(input: string | Date): string {
  const p = parts(input);
  return `${p.day} ${SINDHI_MONTHS[p.month - 1]} ${p.year}`;
}

/** "اربع، 18 نومبر 2026" */
export function formatDateWithDay(input: string | Date): string {
  const p = parts(input);
  return `${SINDHI_WEEKDAYS[p.weekday]}، ${p.day} ${SINDHI_MONTHS[p.month - 1]} ${p.year}`;
}

/** "08:40 رات" — time with a Sindhi day-part label */
export function formatTime(input: string | Date): string {
  const p = parts(input);
  const h12 = p.hour % 12 === 0 ? 12 : p.hour % 12;
  const label =
    p.hour < 5 ? 'رات' : p.hour < 12 ? 'صبح' : p.hour < 16 ? 'منجهند' : p.hour < 19 ? 'شام' : 'رات';
  return `${pad(h12)}:${pad(p.minute)} ${label}`;
}

/** "18 نومبر 2026 · 08:40 رات" */
export function formatDateTime(input: string | Date): string {
  return `${formatDate(input)} · ${formatTime(input)}`;
}

/** Islamic (Hijri, Umm al-Qura) date in Sindhi, e.g. "27 جمادي الاول 1448". */
export function formatHijri(input: string | Date): string | null {
  try {
    const d = typeof input === 'string' ? new Date(input) : input;
    const fmt = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn', {
      timeZone: TZ,
      day: 'numeric',
      month: 'numeric',
      year: 'numeric',
    });
    const p: Record<string, string> = {};
    for (const x of fmt.formatToParts(d)) p[x.type] = x.value;
    const m = Number(p.month);
    const y = String(p.year ?? p.relatedYear ?? '').replace(/\D/g, '');
    if (!m || !p.day || !y) return null;
    return `${p.day} ${HIJRI_MONTHS[m - 1]} ${y}`;
  } catch {
    return null;
  }
}

/** Short Sindhi label for "x minutes/hours ago" — used only client-side. */
export function timeAgo(input: string, now: Date = new Date()): string {
  const diff = Math.max(0, now.getTime() - new Date(input).getTime());
  const min = Math.round(diff / 60000);
  if (min < 1) return 'هينئر';
  if (min < 60) return `${min} منٽ اڳ`;
  const hrs = Math.round(min / 60);
  if (hrs < 24) return `${hrs} ڪلاڪ اڳ`;
  return formatDate(input);
}

/** Estimated reading time in minutes (Sindhi text ~180 words/min). */
export function readingMinutes(words: number): number {
  return Math.max(1, Math.round(words / 180));
}

export function formatViews(n?: number): string {
  if (!n) return '';
  if (n >= 1000) return `${(n / 1000).toFixed(n >= 10000 ? 0 : 1)} هزار`;
  return String(n);
}
