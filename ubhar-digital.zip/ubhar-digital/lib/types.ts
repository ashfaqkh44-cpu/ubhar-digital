/**
 * UBHAR Digital — content model.
 * These types are the contract between the UI and any content source
 * (local JSON today; Sanity / Supabase / headless WordPress later).
 */

export type CategorySlug =
  | 'sindh'
  | 'politics'
  | 'pakistan'
  | 'karachi'
  | 'districts'
  | 'world'
  | 'society'
  | 'education'
  | 'culture'
  | 'sports'
  | 'opinion'
  | 'videos'
  | 'public-voice';

export interface Category {
  slug: CategorySlug;
  /** Sindhi display name */
  name: string;
  /** English name (SEO, admin, search) */
  nameEn: string;
  description: string;
}

export interface Author {
  id: string;
  name: string;
  nameEn: string;
  role: string;
  bio?: string;
}

/** Article body is a list of blocks. A plain string is a paragraph. */
export type ArticleBlock =
  | string
  | { type: 'h2'; text: string }
  | { type: 'quote'; text: string; cite?: string };

export type ArticleType = 'news' | 'video' | 'opinion' | 'public-voice';

export interface VideoInfo {
  /** YouTube / Facebook / direct .mp4 URL */
  url: string;
  /** mm:ss */
  duration: string;
}

export interface Article {
  id: string;
  slug: string;
  type: ArticleType;
  category: CategorySlug;
  title: string;
  summary: string;
  body: ArticleBlock[];
  authorId: string;
  image: string;
  imageAlt: string;
  imageCaption?: string;
  /** ISO 8601 with timezone, e.g. 2026-11-18T19:30:00+05:00 */
  publishedAt: string;
  updatedAt?: string;
  published: boolean;
  /** Shows in homepage hero. Lower heroRank = more important (1 = main story). */
  featured?: boolean;
  heroRank?: number;
  /** Shows in breaking-news ticker */
  breaking?: boolean;
  views?: number;
  /** Sindhi + English + Urdu keywords for search */
  tags?: string[];
  /** District / city label */
  location?: string;
  /** Label for public-voice items, e.g. عوامي شڪايت */
  voiceType?: string;
  video?: VideoInfo;
  /** Marks development sample content */
  sample?: boolean;
}

export interface BreakingItem {
  id: string;
  text: string;
  /** optional link to an article slug */
  slug?: string;
  active: boolean;
}

/** Compact search result returned by /api/search */
export interface SearchHit {
  slug: string;
  title: string;
  summary: string;
  image: string;
  category: string;
  categoryName: string;
  publishedAt: string;
}
