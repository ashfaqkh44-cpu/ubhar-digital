/**
 * Content access layer.
 *
 * Every page reads content ONLY through these async functions. Today they read
 * the local JSON files in /data. To move to a CMS (Sanity, Supabase, Contentful,
 * headless WordPress), re-implement the functions in `source` below so they
 * fetch from the CMS and map results to the types in lib/types.ts — no page or
 * component needs to change. See README → "Connecting a CMS".
 */
import articlesData from '@/data/articles.json';
import authorsData from '@/data/authors.json';
import breakingData from '@/data/breaking.json';
import type { Article, Author, BreakingItem, CategorySlug } from './types';
import { searchArticles } from './search';

interface ContentSource {
  articles(): Promise<Article[]>;
  authors(): Promise<Author[]>;
  breaking(): Promise<BreakingItem[]>;
}

/** Local JSON source (default). */
const localSource: ContentSource = {
  articles: async () => articlesData as Article[],
  authors: async () => authorsData as Author[],
  breaking: async () => breakingData as BreakingItem[],
};

const source: ContentSource = localSource;

const byNewest = (a: Article, b: Article) => +new Date(b.publishedAt) - +new Date(a.publishedAt);

export async function getAllArticles(): Promise<Article[]> {
  const all = await source.articles();
  return all.filter((a) => a.published).sort(byNewest);
}

export async function getArticle(slug: string): Promise<Article | undefined> {
  return (await getAllArticles()).find((a) => a.slug === slug);
}

export async function getArticlesByCategory(category: CategorySlug | 'latest', limit?: number): Promise<Article[]> {
  const all = await getAllArticles();
  const list = category === 'latest' ? all : all.filter((a) => a.category === category);
  return typeof limit === 'number' ? list.slice(0, limit) : list;
}

/** Hero stories: featured items ordered by heroRank. Falls back to newest. */
export async function getHeroArticles(count = 4): Promise<Article[]> {
  const all = await getAllArticles();
  const featured = all
    .filter((a) => a.featured)
    .sort((a, b) => (a.heroRank ?? 99) - (b.heroRank ?? 99));
  const rest = all.filter((a) => !a.featured && a.type === 'news');
  return [...featured, ...rest].slice(0, count);
}

export async function getLatest(limit = 9, exclude: string[] = []): Promise<Article[]> {
  const all = await getAllArticles();
  return all.filter((a) => a.type === 'news' && !exclude.includes(a.slug)).slice(0, limit);
}

export async function getMostRead(limit = 5): Promise<Article[]> {
  const all = await getAllArticles();
  return [...all].sort((a, b) => (b.views ?? 0) - (a.views ?? 0)).slice(0, limit);
}

export async function getRelated(article: Article, limit = 4): Promise<Article[]> {
  const all = await getAllArticles();
  const tags = new Set(article.tags ?? []);
  return all
    .filter((a) => a.slug !== article.slug)
    .map((a) => ({
      a,
      score: (a.category === article.category ? 5 : 0) + (a.tags ?? []).filter((t) => tags.has(t)).length,
    }))
    .filter((x) => x.score > 0)
    .sort((x, y) => y.score - x.score || byNewest(x.a, y.a))
    .slice(0, limit)
    .map((x) => x.a);
}

export async function getBreakingNews(): Promise<BreakingItem[]> {
  const items = (await source.breaking()).filter((b) => b.active);
  // Articles flagged as breaking in the CMS are added automatically.
  const flagged = (await getAllArticles())
    .filter((a) => a.breaking && !items.some((b) => b.slug === a.slug))
    .map((a) => ({ id: a.id, text: a.title, slug: a.slug, active: true }));
  return [...items, ...flagged];
}

export async function getAuthors(): Promise<Author[]> {
  return source.authors();
}

export async function getAuthor(id: string): Promise<Author> {
  const authors = await source.authors();
  return authors.find((a) => a.id === id) ?? { id, name: 'اُڀار نيوز ڊيسڪ', nameEn: 'UBHAR News Desk', role: 'نيوز ڊيسڪ' };
}

export async function search(query: string, limit = 30) {
  return searchArticles(await getAllArticles(), query, limit);
}

export function articleHref(a: Pick<Article, 'slug'>): string {
  return `/news/${a.slug}`;
}

export function wordCount(a: Article): number {
  return a.body
    .map((b) => (typeof b === 'string' ? b : b.text))
    .join(' ')
    .split(/\s+/)
    .filter(Boolean).length;
}
