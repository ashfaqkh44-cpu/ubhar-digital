import type { Metadata } from 'next';
import { site } from './site';
import type { Article, Author, Category } from './types';

export const absoluteUrl = (path = '/') => `${site.url}${path.startsWith('/') ? path : `/${path}`}`;

export function pageMetadata({
  title,
  description,
  path,
  image,
}: {
  title: string;
  description?: string;
  path: string;
  image?: string;
}): Metadata {
  const desc = description ?? site.description;
  const img = image ?? site.ogImage;
  return {
    title,
    description: desc,
    alternates: { canonical: path },
    openGraph: {
      type: 'website',
      locale: site.locale,
      siteName: site.nameSd,
      title,
      description: desc,
      url: path,
      images: [{ url: img, width: 1200, height: 630, alt: title }],
    },
    twitter: { card: 'summary_large_image', title, description: desc, images: [img] },
  };
}

export function articleMetadata(a: Article, author: Author, category?: Category): Metadata {
  const path = `/news/${a.slug}`;
  return {
    title: a.title,
    description: a.summary,
    alternates: { canonical: path },
    authors: [{ name: author.name }],
    keywords: a.tags,
    openGraph: {
      type: 'article',
      locale: site.locale,
      siteName: site.nameSd,
      title: a.title,
      description: a.summary,
      url: path,
      publishedTime: a.publishedAt,
      modifiedTime: a.updatedAt ?? a.publishedAt,
      section: category?.name,
      authors: [author.name],
      tags: a.tags,
      images: [{ url: a.image, width: 1200, height: 675, alt: a.imageAlt }],
    },
    twitter: { card: 'summary_large_image', title: a.title, description: a.summary, images: [a.image] },
  };
}

export function organizationJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@type': 'NewsMediaOrganization',
    name: site.name,
    alternateName: site.nameSd,
    url: site.url,
    logo: { '@type': 'ImageObject', url: absoluteUrl(site.logo) },
    slogan: site.sloganShort,
    sameAs: Object.values(site.social),
    contactPoint: { '@type': 'ContactPoint', email: site.contact.email, contactType: 'customer support' },
  };
}

export function websiteJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: site.nameSd,
    url: site.url,
    inLanguage: 'sd',
    potentialAction: {
      '@type': 'SearchAction',
      target: `${site.url}/search?q={search_term_string}`,
      'query-input': 'required name=search_term_string',
    },
  };
}

export function newsArticleJsonLd(a: Article, author: Author, category?: Category) {
  return {
    '@context': 'https://schema.org',
    '@type': a.type === 'opinion' ? 'OpinionNewsArticle' : 'NewsArticle',
    headline: a.title,
    description: a.summary,
    image: [absoluteUrl(a.image)],
    datePublished: a.publishedAt,
    dateModified: a.updatedAt ?? a.publishedAt,
    inLanguage: 'sd',
    articleSection: category?.name,
    keywords: a.tags?.join(', '),
    mainEntityOfPage: { '@type': 'WebPage', '@id': absoluteUrl(`/news/${a.slug}`) },
    author: { '@type': author.id === 'desk' || author.id === 'editorial' ? 'Organization' : 'Person', name: author.name },
    publisher: {
      '@type': 'NewsMediaOrganization',
      name: site.name,
      logo: { '@type': 'ImageObject', url: absoluteUrl(site.logo) },
    },
    ...(a.video
      ? {
          video: {
            '@type': 'VideoObject',
            name: a.title,
            description: a.summary,
            thumbnailUrl: absoluteUrl(a.image),
            uploadDate: a.publishedAt,
            contentUrl: a.video.url.startsWith('http') ? a.video.url : absoluteUrl(a.video.url),
          },
        }
      : {}),
  };
}

export function breadcrumbJsonLd(items: { name: string; href: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((it, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: it.name,
      item: absoluteUrl(it.href),
    })),
  };
}
