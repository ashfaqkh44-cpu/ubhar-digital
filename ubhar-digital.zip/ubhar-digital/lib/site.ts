/** Global site configuration — edit social links and contact details here. */

const vercelUrl = process.env.VERCEL_PROJECT_PRODUCTION_URL
  ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
  : undefined;

export const site = {
  name: 'UBHAR Digital',
  nameSd: 'اُڀار ڊجيٽل',
  slogan: 'اُڀار ڊجيٽل — خبر، نظر ۽ آواز عوام جو.',
  sloganShort: 'خبر، نظر ۽ آواز عوام جو.',
  description:
    'اُڀار ڊجيٽل — سنڌ ۽ دنيا جون تازيون خبرون، سياست، سماج، تعليم، ثقافت ۽ عوام جو آواز. خبر، نظر ۽ آواز عوام جو.',
  url: (process.env.NEXT_PUBLIC_SITE_URL || vercelUrl || 'http://localhost:3000').replace(/\/$/, ''),
  locale: 'sd_PK',
  logo: '/images/logo/ubhar-logo.png',
  logoWithTagline: '/images/logo/ubhar-logo-tagline.png',
  ogImage: '/images/og-default.jpg',
  /** Show a "sample content" notice while the site still uses demo data. Set to false at launch. */
  showSampleNotice: true,
  contact: {
    email: 'info@ubhar.digital',
    phone: '+92 300 0000000',
    whatsapp: '923000000000',
    address: 'ڪراچي، سنڌ، پاڪستان',
  },
  /** Placeholder social links — replace with the official UBHAR handles. */
  social: {
    facebook: 'https://www.facebook.com/UBHARdigital',
    youtube: 'https://www.youtube.com/@UBHARdigital',
    instagram: 'https://www.instagram.com/UBHARdigital',
    tiktok: 'https://www.tiktok.com/@UBHARdigital',
    x: 'https://x.com/UBHARdigital',
  },
} as const;

export type SocialKey = keyof typeof site.social;

export const socialList: { key: SocialKey; label: string }[] = [
  { key: 'facebook', label: 'Facebook' },
  { key: 'youtube', label: 'YouTube' },
  { key: 'instagram', label: 'Instagram' },
  { key: 'tiktok', label: 'TikTok' },
  { key: 'x', label: 'X' },
];

/** Main navigation, in reading (right-to-left) order. */
export const mainNav: { label: string; href: string }[] = [
  { label: 'هوم', href: '/' },
  { label: 'تازيون خبرون', href: '/category/latest' },
  { label: 'پاڪستان', href: '/category/pakistan' },
  { label: 'سنڌ', href: '/category/sindh' },
  { label: 'سياست', href: '/category/politics' },
  { label: 'ڪراچي', href: '/category/karachi' },
  { label: 'ضلعي خبرون', href: '/category/districts' },
  { label: 'دنيا', href: '/category/world' },
  { label: 'سماج', href: '/category/society' },
  { label: 'تعليم', href: '/category/education' },
  { label: 'ثقافت', href: '/category/culture' },
  { label: 'راءِ', href: '/category/opinion' },
  { label: 'وڊيوز', href: '/category/videos' },
];

export const footerNav: { label: string; href: string }[] = [
  { label: 'اُڀار بابت', href: '/about' },
  { label: 'رابطو', href: '/contact' },
  { label: 'ادارتي پاليسي', href: '/editorial-policy' },
  { label: 'رازداري پاليسي', href: '/privacy-policy' },
  { label: 'شرط ۽ ضابطا', href: '/terms' },
  { label: 'اُڀار تي اشتهار', href: '/advertise' },
];
