import categoriesData from '@/data/categories.json';
import type { Category, CategorySlug } from './types';

export const categories = categoriesData as Category[];

/** Virtual category: every article, newest first. */
export const LATEST: Category = {
  slug: 'latest' as CategorySlug,
  name: 'تازيون خبرون',
  nameEn: 'Latest News',
  description: 'اُڀار ڊجيٽل تي شايع ٿيندڙ سڀ تازيون خبرون — نئين کان پراڻي ترتيب ۾.',
};

export function getCategory(slug: string): Category | undefined {
  if (slug === 'latest') return LATEST;
  return categories.find((c) => c.slug === slug);
}

export function categoryHref(slug: CategorySlug | 'latest'): string {
  return `/category/${slug}`;
}

export function categoryName(slug: CategorySlug): string {
  return getCategory(slug)?.name ?? slug;
}
