import type { Article } from './types';
import { getCategory } from './categories';

/**
 * Normalise Sindhi / Urdu / Arabic / English text so that the same word typed
 * with Urdu letters (ک ی ہ) or with diacritics still matches Sindhi content.
 */
export function normalize(input: string): string {
  return input
    .toLowerCase()
    .normalize('NFC')
    .replace(/[ً-ٰٟۖ-ۭ]/g, '') // harakat & Quranic marks
    .replace(/ـ/g, '') // tatweel
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/[ىیۍې]/g, 'ي') // Urdu/Farsi yeh → Arabic yeh (used in Sindhi)
    .replace(/ۓ|ے/g, 'ي')
    .replace(/ک/g, 'ڪ') // Urdu kaf → Sindhi kaf
    .replace(/[ہۃةھ]/g, 'ه') // heh variants
    .replace(/ؤ/g, 'و')
    .replace(/ئ/g, 'ي')
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function blockText(a: Article): string {
  return a.body.map((b) => (typeof b === 'string' ? b : b.text)).join(' ');
}

export interface SearchResult {
  article: Article;
  score: number;
}

/** Simple weighted full-text search over titles, summaries, tags and body. */
export function searchArticles(articles: Article[], query: string, limit = 30): SearchResult[] {
  const q = normalize(query);
  if (!q) return [];
  const terms = q.split(' ').filter((t) => t.length > 0);

  const results: SearchResult[] = [];
  for (const a of articles) {
    const cat = getCategory(a.category);
    const fields = {
      title: normalize(a.title),
      summary: normalize(a.summary),
      tags: normalize([...(a.tags ?? []), cat?.name ?? '', cat?.nameEn ?? '', a.location ?? '', a.slug.replace(/-/g, ' ')].join(' ')),
      body: normalize(blockText(a)),
    };
    let score = 0;
    let allMatched = true;
    for (const t of terms) {
      let s = 0;
      if (fields.title.includes(t)) s += 10;
      if (fields.tags.includes(t)) s += 6;
      if (fields.summary.includes(t)) s += 4;
      if (fields.body.includes(t)) s += 1;
      if (s === 0) allMatched = false;
      score += s;
    }
    if (fields.title.includes(q)) score += 15; // whole phrase bonus
    if (score > 0 && (allMatched || terms.length === 1)) results.push({ article: a, score });
  }
  return results
    .sort((x, y) => y.score - x.score || +new Date(y.article.publishedAt) - +new Date(x.article.publishedAt))
    .slice(0, limit);
}
