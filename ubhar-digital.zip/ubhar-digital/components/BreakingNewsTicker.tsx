import Link from 'next/link';
import type { BreakingItem } from '@/lib/types';
import type { CSSProperties } from 'react';

/**
 * Breaking news strip. Pure CSS animation (no JavaScript), RTL-aware:
 * content flows left→right so each Sindhi headline is read from its beginning.
 * Pauses on hover/focus; respects prefers-reduced-motion.
 */
export function BreakingNewsTicker({ items }: { items: BreakingItem[] }) {
  if (!items.length) return null;
  const style = { '--ticker-duration': `${Math.max(30, items.length * 14)}s` } as CSSProperties;

  const list = (hidden: boolean) => (
    <ul className="flex shrink-0 items-center" aria-hidden={hidden || undefined}>
      {items.map((item) => (
        <li key={`${hidden ? 'b' : 'a'}-${item.id}`} className="flex items-center">
          {item.slug ? (
            <Link
              href={`/news/${item.slug}`}
              tabIndex={hidden ? -1 : undefined}
              className="px-6 whitespace-nowrap hover:text-brand focus:text-brand"
            >
              {item.text}
            </Link>
          ) : (
            <span className="px-6 whitespace-nowrap">{item.text}</span>
          )}
          <span className="size-1.5 shrink-0 rotate-45 bg-brand" aria-hidden />
        </li>
      ))}
    </ul>
  );

  return (
    <section aria-label="بريڪنگ نيوز" className="border-b border-white/10 bg-ink text-white">
      <div className="container-x flex h-11 items-stretch md:h-12">
        <div className="slant relative z-10 flex shrink-0 items-center gap-2 bg-brand font-display text-[15px] font-extrabold md:text-base">
          <span className="size-2 animate-pulse-dot rounded-full bg-white" aria-hidden />
          بريڪنگ نيوز
        </div>
        <div className="group relative flex-1 overflow-hidden" style={style}>
          <div className="pointer-events-none absolute inset-y-0 start-0 z-10 w-6 bg-gradient-to-l from-ink to-transparent" />
          <div className="pointer-events-none absolute inset-y-0 end-0 z-10 w-10 bg-gradient-to-r from-ink to-transparent" />
          <div className="flex h-full w-max animate-ticker items-center text-[15px] font-medium group-hover:[animation-play-state:paused] group-focus-within:[animation-play-state:paused] md:text-base">
            {list(false)}
            {list(true)}
          </div>
        </div>
      </div>
    </section>
  );
}
