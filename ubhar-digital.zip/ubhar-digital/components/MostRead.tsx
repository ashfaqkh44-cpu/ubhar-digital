import Link from 'next/link';
import type { Article } from '@/lib/types';
import { articleHref } from '@/lib/content';
import { categoryName } from '@/lib/categories';
import { formatViews } from '@/lib/date';
import { Icon } from './Icon';

export function MostRead({ articles, title = 'وڌيڪ پڙهيل خبرون', dark = false }: { articles: Article[]; title?: string; dark?: boolean }) {
  return (
    <section aria-labelledby="most-read-title" className={dark ? 'bg-ink p-5 text-white' : 'border-t-[3px] border-ink bg-mist p-5'}>
      <h2 id="most-read-title" className="flex items-center gap-2 text-xl">
        <Icon name="trending" size={22} className="text-brand" />
        {title}
      </h2>
      <ol className="mt-4">
        {articles.map((a, i) => (
          <li key={a.slug} className={`group relative flex gap-4 py-3.5 ${i > 0 ? (dark ? 'border-t border-white/10' : 'border-t border-line') : ''}`}>
            <span className="w-9 shrink-0 font-display text-[2.1rem] leading-none font-black text-brand tabular-nums" aria-hidden>
              {i + 1}
            </span>
            <div className="min-w-0">
              <h3 className="text-[15px] leading-[1.75] font-bold">
                <Link href={articleHref(a)} className="headline-link after:absolute after:inset-0 after:content-['']">
                  {a.title}
                </Link>
              </h3>
              <p className={`mt-1 flex items-center gap-3 text-xs ${dark ? 'text-white/50' : 'text-steel'}`}>
                <span className="font-bold whitespace-nowrap text-brand">{categoryName(a.category)}</span>
                {a.views ? (
                  <span className="inline-flex items-center gap-1 whitespace-nowrap" title="ڀيرا پڙهيو ويو">
                    <Icon name="eye" size={13} />
                    {formatViews(a.views)}
                  </span>
                ) : null}
              </p>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}
