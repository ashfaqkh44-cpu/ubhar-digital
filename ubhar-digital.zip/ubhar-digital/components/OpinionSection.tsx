import Link from 'next/link';
import type { Article, Author } from '@/lib/types';
import { articleHref } from '@/lib/content';
import { SectionHeading } from './SectionHeading';
import { NewsImage } from './NewsImage';
import { TimeStamp } from './TimeStamp';
import { Icon } from './Icon';

export function AuthorAvatar({ author, size = 40 }: { author: Author; size?: number }) {
  const initial = author.name.trim().charAt(0);
  return (
    <span
      aria-hidden
      className="inline-flex shrink-0 items-center justify-center rounded-full border-2 border-brand bg-ink font-display font-black text-white"
      style={{ width: size, height: size, fontSize: size * 0.42 }}
    >
      {initial}
    </span>
  );
}

export function OpinionCard({ article: a, author }: { article: Article; author: Author }) {
  return (
    <article className="reveal group relative flex flex-col bg-white">
      <div className="relative">
        <NewsImage src={a.image} alt={a.imageAlt} aspect="aspect-[16/10]" sizes="(min-width:1024px) 300px, (min-width:640px) 50vw, 100vw" imgClassName="grayscale-[60%] group-hover:grayscale-0" />
        <span className="absolute -bottom-5 end-5 flex size-11 items-center justify-center bg-brand text-white">
          <Icon name="quote" size={20} />
        </span>
      </div>
      <div className="flex flex-1 flex-col p-5 pt-6">
        <div className="flex items-center gap-3">
          <AuthorAvatar author={author} />
          <div className="min-w-0 leading-tight">
            <p className="truncate text-sm font-bold">{author.name}</p>
            <p className="text-xs text-steel">{author.role}</p>
          </div>
        </div>
        <h3 className="mt-4 text-lg leading-[1.65]">
          <Link href={articleHref(a)} className="headline-link after:absolute after:inset-0 after:content-['']">
            {a.title}
          </Link>
        </h3>
        <p className="mt-2 line-clamp-3 font-naskh text-[15px] leading-8 text-slate">{a.summary}</p>
        <TimeStamp iso={a.publishedAt} withTime={false} className="mt-auto pt-4" />
      </div>
    </article>
  );
}

export function OpinionSection({ items }: { items: { article: Article; author: Author }[] }) {
  if (!items.length) return null;
  return (
    <section aria-labelledby="sec-opinion" className="bg-mist py-12 md:py-16">
      <div className="container-x">
        <SectionHeading id="sec-opinion" title="راءِ ۽ تجزيو" href="/category/opinion" linkLabel="سڀ لکڻيون ڏسو" />
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {items.map(({ article, author }) => (
            <OpinionCard key={article.slug} article={article} author={author} />
          ))}
        </div>
      </div>
    </section>
  );
}
