import Image from 'next/image';

/** Responsive, lazy-loaded image with a fixed aspect ratio (prevents layout shift). */
export function NewsImage({
  src,
  alt,
  sizes,
  aspect = 'aspect-video',
  priority = false,
  className = '',
  imgClassName = '',
}: {
  src: string;
  alt: string;
  sizes: string;
  aspect?: string;
  priority?: boolean;
  className?: string;
  imgClassName?: string;
}) {
  return (
    <div className={`relative overflow-hidden bg-graphite ${aspect} ${className}`}>
      <Image
        src={src}
        alt={alt}
        fill
        sizes={sizes}
        priority={priority}
        className={`object-cover transition-transform duration-500 ease-out group-hover:scale-[1.04] ${imgClassName}`}
      />
    </div>
  );
}
