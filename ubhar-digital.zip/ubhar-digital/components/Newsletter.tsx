'use client';

import { useState, type FormEvent } from 'react';
import { Icon } from './Icon';
import { SocialLinks } from './SocialLinks';

type Status = 'idle' | 'loading' | 'success' | 'error';
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function NewsletterForm({ compact = false }: { compact?: boolean }) {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<Status>('idle');
  const [message, setMessage] = useState('');

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!EMAIL_RE.test(email.trim())) {
      setStatus('error');
      setMessage('مهرباني ڪري صحيح اي ميل ايڊريس لکو.');
      return;
    }
    setStatus('loading');
    try {
      const res = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim() }),
      });
      const data = (await res.json()) as { ok: boolean; message?: string };
      if (!res.ok || !data.ok) throw new Error(data.message);
      setStatus('success');
      setMessage(data.message ?? 'شڪريه! توهان جي اي ميل وصول ٿي وئي.');
      setEmail('');
    } catch (err) {
      setStatus('error');
      setMessage(err instanceof Error && err.message ? err.message : 'ڪجهه غلط ٿي ويو، ٻيهر ڪوشش ڪريو.');
    }
  }

  return (
    <form onSubmit={onSubmit} noValidate className="w-full">
      <div className={`flex ${compact ? 'flex-col gap-2' : 'flex-col gap-3 sm:flex-row sm:gap-0'}`}>
        <label htmlFor={compact ? 'nl-email-c' : 'nl-email'} className="sr-only">
          اي ميل ايڊريس
        </label>
        <input
          id={compact ? 'nl-email-c' : 'nl-email'}
          type="email"
          inputMode="email"
          autoComplete="email"
          dir="ltr"
          placeholder="you@example.com"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
            if (status === 'error') setStatus('idle');
          }}
          aria-invalid={status === 'error'}
          aria-describedby="nl-msg"
          className={`h-13 w-full min-w-0 border-2 border-transparent bg-white px-4 text-start text-ink placeholder:text-steel focus:border-ink focus:outline-none ${compact ? '' : 'sm:flex-1'}`}
        />
        <button
          type="submit"
          disabled={status === 'loading'}
          className="inline-flex h-13 items-center justify-center gap-2 bg-ink px-7 font-bold text-white transition-colors hover:bg-charcoal disabled:opacity-60"
        >
          {status === 'loading' ? 'موڪلي رهيا آهيون...' : 'سبسڪرائب ڪريو'}
          {status !== 'loading' && <Icon name="arrowLeft" size={16} />}
        </button>
      </div>
      <p id="nl-msg" role="status" aria-live="polite" className={`mt-2 min-h-6 text-sm font-semibold ${status === 'error' ? 'text-white underline decoration-2' : 'text-white/90'}`}>
        {status === 'success' && <Icon name="check" size={14} className="me-1 inline" />}
        {message}
      </p>
    </form>
  );
}

export function Newsletter() {
  return (
    <section aria-labelledby="sec-newsletter" className="relative overflow-hidden bg-brand text-white">
      <div aria-hidden className="absolute -top-24 -start-24 size-80 rounded-full bg-ink/15" />
      <div aria-hidden className="absolute -bottom-32 end-[10%] size-96 rounded-full border border-white/25" />
      <div aria-hidden className="dots absolute inset-y-0 end-0 w-1/3 text-white/15" />
      <div className="container-x relative grid items-center gap-8 py-12 md:py-14 lg:grid-cols-2">
        <div>
          <h2 id="sec-newsletter" className="text-[2rem] leading-tight font-black md:text-[2.5rem]">
            اُڀار سان گڏ رهو
          </h2>
          <p className="mt-3 max-w-lg font-naskh text-lg leading-9 text-white/90">
            تازين خبرن، خاص رپورٽن ۽ ڪهاڻين سان باخبر رهڻ لاءِ اسان جي نيوز ليٽر ۾ شامل ٿيو.
          </p>
          <p className="ltr mt-1 text-sm text-white/70">Stay updated with the latest news and stories.</p>
        </div>
        <div>
          <NewsletterForm />
          <div className="mt-2 flex flex-wrap items-center gap-3">
            <span className="text-sm font-bold">اسان کي فالو ڪريو:</span>
            <SocialLinks size={18} boxed itemClassName="text-white" />
          </div>
        </div>
      </div>
    </section>
  );
}
