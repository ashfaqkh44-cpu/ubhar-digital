import Link from 'next/link';
import type { Article } from '@/lib/types';
import { articleHref } from '@/lib/content';
import { NewsImage } from './NewsImage';
import { Icon } from './Icon';
import { TimeStamp } from './TimeStamp';
import { categoryName } from '@/lib/categories';

/** Video card styled like UBHAR's black/red/white video posters. */
export function VideoNewsCard({ article: a, featured = false }: { article: Article; featured?: boolean }) {
  return (
    <article className="group relative">
      <div className="relative">
        <NewsImage
          src={a.image}
          alt={a.imageAlt}
          aspect={featured ? 'aspect-video' : 'aspect-video'}
          sizes={featured ? '(min-width:1024px) 760px, 100vw' : '(min-width:1024px) 280px, 50vw'}
          imgClassName="opacity-85 group-hover:opacity-100"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/90 via-transparent to-transparent" />
        {/* play button */}
        <span
          className={`absolute inset-0 m-auto flex items-center justify-center rounded-full bg-brand text-white shadow-[0_0_0_8px_rgba(229,9,32,.25)] transition-transform duration-300 group-hover:scale-110 ${
            featured ? 'size-20 md:size-24' : 'size-12'
          }`}
        >
          <Icon name="play" size={featured ? 34 : 18} className="-me-1" />
        </span>
        <span className="absolute top-3 start-3 slant bg-brand py-0.5 text-xs font-bold text-white">وڊيو</span>
        {a.video?.duration && (
          <span className="ltr absolute bottom-3 end-3 bg-ink/90 px-2 py-0.5 text-xs font-semibold text-white">{a.video.duration}</span>
        )}
      </div>
      <div className={featured ? 'pt-5' : 'pt-3'}>
        <p className="text-xs font-bold text-brand">{categoryName(a.category)}</p>
        <h3 className={`mt-1 text-white ${featured ? 'text-2xl leading-[1.55] md:text-[1.9rem]' : 'text-[15px] leading-[1.7] font-bold'}`}>
          <Link href={articleHref(a)} className="headline-link after:absolute after:inset-0 after:content-['']">
            {a.title}
          </Link>
        </h3>
        {featured && <p className="mt-2 line-clamp-2 font-naskh leading-8 text-white/65">{a.summary}</p>}
        {featured && <TimeStamp iso={a.publishedAt} className="mt-3 !text-white/50" />}
      </div>
    </article>
  );
}
