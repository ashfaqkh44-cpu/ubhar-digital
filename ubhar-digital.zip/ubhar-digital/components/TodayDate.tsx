'use client';

import { useEffect, useState } from 'react';
import { formatDateWithDay, formatHijri } from '@/lib/date';

/** Current date in Sindhi (+ Hijri). Rendered after mount so cached pages always show today's date. */
export function TodayDate({ showHijri = true }: { showHijri?: boolean }) {
  const [text, setText] = useState<{ greg: string; hijri: string | null } | null>(null);

  useEffect(() => {
    const now = new Date();
    setText({ greg: formatDateWithDay(now), hijri: formatHijri(now) });
  }, []);

  return (
    <span className="inline-flex min-w-[11rem] items-center gap-2" aria-live="off">
      {text ? (
        <>
          <time dateTime={new Date().toISOString().slice(0, 10)}>{text.greg}</time>
          {showHijri && text.hijri && (
            <span className="hidden text-white/50 md:inline">
              <span className="mx-1 text-brand">•</span>
              {text.hijri} هجري
            </span>
          )}
        </>
      ) : (
        <span className="inline-block h-3 w-40 animate-pulse bg-white/10" />
      )}
    </span>
  );
}
