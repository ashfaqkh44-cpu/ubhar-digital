import Link from 'next/link';
import { getCategory } from '@/lib/categories';
import type { CategorySlug } from '@/lib/types';

export function CategoryBadge({
  slug,
  variant = 'solid',
  className = '',
  link = true,
}: {
  slug: CategorySlug;
  variant?: 'solid' | 'text' | 'dark';
  className?: string;
  link?: boolean;
}) {
  const cat = getCategory(slug);
  if (!cat) return null;
  const styles = {
    solid: 'slant bg-brand py-0.5 text-white hover:bg-brand-dark',
    dark: 'slant bg-ink py-0.5 text-white hover:bg-brand',
    text: 'text-brand hover:text-brand-dark',
  }[variant];
  const cls = `relative z-10 inline-flex items-center text-[13px] font-bold leading-6 transition-colors ${styles} ${className}`;
  return link ? (
    <Link href={`/category/${cat.slug}`} className={cls}>
      {cat.name}
    </Link>
  ) : (
    <span className={cls}>{cat.name}</span>
  );
}
