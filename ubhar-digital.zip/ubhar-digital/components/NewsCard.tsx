import Link from 'next/link';
import type { Article } from '@/lib/types';
import { articleHref } from '@/lib/content';
import { CategoryBadge } from './CategoryBadge';
import { NewsImage } from './NewsImage';
import { TimeStamp } from './TimeStamp';
import { Icon } from './Icon';

type Variant = 'default' | 'horizontal' | 'compact' | 'overlay' | 'text';

/**
 * Reusable news card. Whole card is clickable through a stretched headline link,
 * while the category badge stays independently clickable.
 */
export function NewsCard({
  article: a,
  variant = 'default',
  showSummary = true,
  showCategory = true,
  priority = false,
  headingLevel = 3,
  className = '',
}: {
  article: Article;
  variant?: Variant;
  showSummary?: boolean;
  showCategory?: boolean;
  priority?: boolean;
  headingLevel?: 2 | 3 | 4;
  className?: string;
}) {
  const H = `h${headingLevel}` as 'h2' | 'h3' | 'h4';
  const href = articleHref(a);
  const isVideo = a.type === 'video';
  const stretched = 'after:absolute after:inset-0 after:content-[""]';

  const playBadge = isVideo ? (
    <span className="absolute bottom-2 start-2 inline-flex items-center gap-1 bg-brand px-2 py-0.5 text-xs font-bold text-white">
      <Icon name="play" size={11} />
      <span className="ltr">{a.video?.duration}</span>
    </span>
  ) : null;

  if (variant === 'overlay') {
    return (
      <article className={`group relative overflow-hidden bg-ink ${className}`}>
        <NewsImage src={a.image} alt={a.imageAlt} priority={priority} aspect="aspect-[4/3] sm:aspect-[16/10]" sizes="(min-width:1024px) 50vw, 100vw" imgClassName="opacity-90" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/55 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-5 md:p-7">
          {showCategory && <CategoryBadge slug={a.category} />}
          <H className="mt-3 text-xl leading-[1.6] text-white md:text-[1.75rem]">
            <Link href={href} className={`headline-link ${stretched}`}>
              {a.title}
            </Link>
          </H>
          {showSummary && <p className="mt-2 line-clamp-2 font-naskh text-white/75 max-md:hidden">{a.summary}</p>}
          <TimeStamp iso={a.publishedAt} className="mt-3 !text-white/60" />
        </div>
      </article>
    );
  }

  if (variant === 'horizontal') {
    return (
      <article className={`group relative flex gap-4 md:gap-6 ${className}`}>
        <div className="relative w-[38%] shrink-0 md:w-[42%]">
          <NewsImage src={a.image} alt={a.imageAlt} priority={priority} sizes="(min-width:1024px) 320px, 40vw" />
          {playBadge}
        </div>
        <div className="min-w-0 flex-1">
          {showCategory && <CategoryBadge slug={a.category} variant="text" />}
          <H className="mt-1 text-[1.05rem] leading-[1.65] md:text-xl">
            <Link href={href} className={`headline-link ${stretched}`}>
              {a.title}
            </Link>
          </H>
          {showSummary && (
            <p className="mt-2 line-clamp-2 font-naskh text-[15px] leading-8 text-slate max-sm:hidden">{a.summary}</p>
          )}
          <TimeStamp iso={a.publishedAt} className="mt-2" />
        </div>
      </article>
    );
  }

  if (variant === 'compact') {
    return (
      <article className={`group relative flex items-start gap-3 ${className}`}>
        <div className="relative w-28 shrink-0 sm:w-32">
          <NewsImage src={a.image} alt={a.imageAlt} aspect="aspect-[4/3]" sizes="128px" />
          {isVideo && (
            <span className="absolute inset-0 m-auto flex size-8 items-center justify-center rounded-full bg-brand text-white">
              <Icon name="play" size={12} />
            </span>
          )}
        </div>
        <div className="min-w-0 flex-1">
          {showCategory && <CategoryBadge slug={a.category} variant="text" className="!text-xs" />}
          <H className="text-[15px] leading-[1.7] font-bold md:text-base">
            <Link href={href} className={`headline-link ${stretched}`}>
              {a.title}
            </Link>
          </H>
          <TimeStamp iso={a.publishedAt} withTime={false} className="mt-1 !text-xs" />
        </div>
      </article>
    );
  }

  if (variant === 'text') {
    return (
      <article className={`group relative flex gap-3 ${className}`}>
        <span className="mt-3 size-2 shrink-0 rotate-45 bg-brand" aria-hidden />
        <div>
          <H className="text-base leading-[1.75] font-bold">
            <Link href={href} className={`headline-link ${stretched}`}>
              {a.title}
            </Link>
          </H>
          <TimeStamp iso={a.publishedAt} className="mt-1 !text-xs" />
        </div>
      </article>
    );
  }

  // default — vertical card
  return (
    <article className={`reveal group relative flex flex-col ${className}`}>
      <div className="relative">
        <NewsImage
          src={a.image}
          alt={a.imageAlt}
          priority={priority}
          sizes="(min-width:1280px) 300px, (min-width:1024px) 25vw, (min-width:640px) 50vw, 100vw"
        />
        {showCategory && (
          <div className="absolute top-0 start-0">
            <CategoryBadge slug={a.category} />
          </div>
        )}
        {playBadge}
      </div>
      <div className="flex flex-1 flex-col pt-4">
        <H className="text-lg leading-[1.65] md:text-[1.2rem]">
          <Link href={href} className={`headline-link ${stretched}`}>
            {a.title}
          </Link>
        </H>
        {showSummary && <p className="mt-2 line-clamp-2 font-naskh text-[15px] leading-8 text-slate">{a.summary}</p>}
        <div className="mt-auto flex flex-wrap items-center justify-between gap-x-3 gap-y-1 pt-3">
          <TimeStamp iso={a.publishedAt} />
          <span className="inline-flex items-center gap-1 text-[13px] font-bold whitespace-nowrap text-brand opacity-80 transition-opacity group-hover:opacity-100">
            وڌيڪ پڙهو
            <Icon name="arrowLeft" size={14} />
          </span>
        </div>
      </div>
    </article>
  );
}
