import Link from 'next/link';
import type { Article } from '@/lib/types';
import { articleHref } from '@/lib/content';
import { CategoryBadge } from './CategoryBadge';
import { NewsImage } from './NewsImage';
import { TimeStamp } from './TimeStamp';
import { Icon } from './Icon';

/** Homepage lead: one dominant story + 3 secondary stories. */
export function HeroNews({ main, secondary }: { main: Article; secondary: Article[] }) {
  return (
    <section aria-labelledby="hero-title" className="container-x pt-6 md:pt-8">
      <div className="grid gap-6 lg:grid-cols-12 lg:gap-8">
        {/* Main featured story */}
        <article className="group relative bg-ink lg:col-span-8">
          <Link href={articleHref(main)} tabIndex={-1} aria-hidden className="relative block">
            <NewsImage
              src={main.image}
              alt={main.imageAlt}
              priority
              aspect="aspect-[16/10] md:aspect-[16/9]"
              sizes="(min-width:1280px) 850px, (min-width:1024px) 66vw, 100vw"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-transparent max-md:hidden" />
            <span aria-hidden className="absolute top-0 end-0 h-1.5 w-1/3 bg-brand" />
          </Link>
          <div className="p-5 md:absolute md:inset-x-0 md:bottom-0 md:p-8 lg:p-10">
            <div className="flex flex-wrap items-center gap-3">
              <CategoryBadge slug={main.category} />
              <span className="inline-flex items-center gap-1.5 text-[13px] font-bold text-white/90">
                <span className="size-1.5 animate-pulse-dot rounded-full bg-brand" />
                اهم خبر
              </span>
            </div>
            <h2 id="hero-title" className="mt-3 text-[1.6rem] leading-[1.55] font-black text-white md:text-[2.2rem] lg:text-[2.6rem]">
              <Link href={articleHref(main)} className="headline-link after:absolute after:inset-0 after:content-['']">
                {main.title}
              </Link>
            </h2>
            <p className="mt-3 max-w-3xl font-naskh text-base leading-8 text-white/75 md:text-lg md:leading-9">{main.summary}</p>
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
              <TimeStamp iso={main.publishedAt} className="!text-white/60" />
              <span className="inline-flex items-center gap-1.5 text-sm font-bold text-white transition-colors group-hover:text-brand">
                مڪمل خبر پڙهو
                <Icon name="arrowLeft" size={16} />
              </span>
            </div>
          </div>
        </article>

        {/* Secondary stories */}
        <div className="grid gap-6 sm:grid-cols-3 lg:col-span-4 lg:grid-cols-1 lg:content-between lg:gap-0 lg:divide-y lg:divide-line">
          {secondary.map((a, i) => (
            <article key={a.slug} className={`group relative flex flex-col gap-3 lg:flex-row lg:gap-4 ${i > 0 ? 'lg:pt-5' : ''} ${i < secondary.length - 1 ? 'lg:pb-5' : ''}`}>
              <div className="relative lg:w-40 lg:shrink-0">
                <NewsImage src={a.image} alt={a.imageAlt} priority={i === 0} sizes="(min-width:1024px) 160px, (min-width:640px) 33vw, 100vw" aspect="aspect-video lg:aspect-[4/3]" />
              </div>
              <div className="min-w-0 flex-1">
                <CategoryBadge slug={a.category} variant="text" />
                <h3 className="mt-0.5 text-lg leading-[1.65] font-bold lg:text-[1.05rem]">
                  <Link href={articleHref(a)} className="headline-link after:absolute after:inset-0 after:content-['']">
                    {a.title}
                  </Link>
                </h3>
                <TimeStamp iso={a.publishedAt} className="mt-1.5 !text-xs" />
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
