'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { mainNav } from '@/lib/site';

export function isActive(pathname: string, href: string) {
  if (href === '/') return pathname === '/';
  return pathname === href || pathname.startsWith(`${href}/`) || pathname.startsWith(`${href}?`);
}

/** Desktop: full horizontal bar. Mobile: horizontally scrollable strip (plus the hamburger drawer). */
export function MainNav() {
  const pathname = usePathname() ?? '/';
  return (
    <nav aria-label="مکيه مينيو" className="sticky top-0 z-40 border-b-[3px] border-brand bg-charcoal text-white shadow-[0_6px_20px_-12px_rgba(0,0,0,.6)]">
      <div className="container-x">
        <ul className="no-scrollbar -mx-1 flex items-stretch overflow-x-auto lg:justify-between">
          {mainNav.map((item) => {
            const active = isActive(pathname, item.href);
            return (
              <li key={item.href} className="shrink-0">
                <Link
                  href={item.href}
                  aria-current={active ? 'page' : undefined}
                  className={`relative flex h-12 items-center px-3 text-[15px] font-semibold whitespace-nowrap transition-colors xl:px-3.5 ${
                    active ? 'bg-brand text-white' : 'text-white/85 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
}
