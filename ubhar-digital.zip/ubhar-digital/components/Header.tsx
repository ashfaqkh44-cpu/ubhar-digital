import Link from 'next/link';
import { Logo } from './Logo';
import { TopBar } from './TopBar';
import { MainNav } from './MainNav';
import { MobileNavigation } from './MobileNavigation';
import { SearchButton } from './SearchButton';
import { Icon } from './Icon';
import { site } from '@/lib/site';

export function Header() {
  return (
    <>
      <header className="bg-ink text-white">
        <TopBar />
        <div className="relative overflow-hidden">
          {/* logo-inspired decoration: thin red ring + dotted texture */}
          <div aria-hidden className="pointer-events-none absolute -top-24 end-[18%] hidden size-64 rounded-full border border-brand/40 lg:block" />
          <div aria-hidden className="dots pointer-events-none absolute inset-y-0 end-0 hidden w-72 text-white/[0.07] lg:block" />

          <div className="container-x relative flex h-[76px] items-center justify-between gap-4 md:h-[96px]">
            <div className="flex items-center gap-5">
              <Logo height={80} priority imgClassName="h-[58px] w-auto md:h-[80px]" />
              <div className="hidden border-s border-white/15 ps-5 lg:block">
                <p className="font-display text-lg font-extrabold leading-tight">{site.nameSd}</p>
                <p className="mt-1 flex items-center gap-2 text-sm text-white/60">
                  <span className="size-1.5 rounded-full bg-brand" />
                  {site.sloganShort}
                  <span className="size-1.5 rounded-full bg-brand" />
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1 sm:gap-2">
              <SearchButton
                label
                className="hidden h-11 border border-white/15 px-4 text-sm text-white/80 hover:border-white/40 hover:text-white md:inline-flex"
              />
              <SearchButton size={22} className="inline-flex size-11 text-white md:hidden" />
              <Link
                href="/category/videos"
                className="slant hidden h-11 items-center gap-2 bg-brand text-sm font-bold text-white transition-colors hover:bg-brand-dark sm:inline-flex"
              >
                <Icon name="play" size={14} />
                وڊيو خبرون
              </Link>
              <MobileNavigation />
            </div>
          </div>
        </div>
      </header>
      <MainNav />
    </>
  );
}
