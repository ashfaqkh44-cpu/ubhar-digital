'use client';

import { Icon } from './Icon';

export const OPEN_SEARCH_EVENT = 'ubhar:open-search';

/** Opens the search modal. Pass a display class (e.g. `inline-flex` or `hidden md:inline-flex`) in className. Falls back to the /search page when JavaScript is unavailable. */
export function SearchButton({ className = '', size = 20, label = false }: { className?: string; size?: number; label?: boolean }) {
  return (
    <a
      href="/search"
      onClick={(e) => {
        e.preventDefault();
        window.dispatchEvent(new CustomEvent(OPEN_SEARCH_EVENT));
      }}
      aria-label="خبرون ڳوليو"
      className={`items-center justify-center gap-2 transition-colors ${className || 'inline-flex'}`}
    >
      <Icon name="search" size={size} />
      {label && <span>ڳوليو</span>}
    </a>
  );
}
