'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Article, ArticleBlock, ArticleType, Author, BreakingItem, Category, CategorySlug } from '@/lib/types';
import { Icon } from '../Icon';
import { Logo } from '../Logo';
import { formatDateTime } from '@/lib/date';

const STORAGE_KEY = 'ubhar-admin-v1';
type Tab = 'articles' | 'breaking' | 'authors' | 'publish';

/* ---------- helpers ---------- */
function bodyToText(body: ArticleBlock[]): string {
  return body
    .map((b) => (typeof b === 'string' ? b : b.type === 'h2' ? `## ${b.text}` : `> ${b.text}${b.cite ? ` — ${b.cite}` : ''}`))
    .join('\n\n');
}
function textToBody(text: string): ArticleBlock[] {
  return text
    .split(/\n\s*\n/)
    .map((p) => p.trim())
    .filter(Boolean)
    .map((p) => {
      if (p.startsWith('## ')) return { type: 'h2' as const, text: p.slice(3).trim() };
      if (p.startsWith('> ')) {
        const [text, cite] = p.slice(2).split(' — ');
        return { type: 'quote' as const, text: text.trim(), ...(cite ? { cite: cite.trim() } : {}) };
      }
      return p;
    });
}
/** ISO (+05:00) <-> datetime-local in Pakistan time */
function isoToLocal(iso: string): string {
  const d = new Date(new Date(iso).getTime() + 5 * 3600 * 1000);
  return d.toISOString().slice(0, 16);
}
function localToIso(local: string): string {
  return `${local}:00+05:00`;
}
function download(name: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2) + '\n'], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}
function emptyArticle(): Article {
  const now = new Date();
  return {
    id: `a${now.getTime()}`,
    slug: `news-${now.getTime().toString(36)}`,
    type: 'news',
    category: 'sindh',
    title: '',
    summary: '',
    body: [],
    authorId: 'desk',
    image: '/images/news/town-1.jpg',
    imageAlt: '',
    publishedAt: localToIso(isoToLocal(now.toISOString())),
    published: false,
    tags: [],
  };
}

/* ---------- small UI bits ---------- */
const Badge = ({ children, tone = 'gray' }: { children: ReactNode; tone?: 'red' | 'dark' | 'gray' | 'green' }) => {
  const t = { red: 'bg-brand text-white', dark: 'bg-ink text-white', gray: 'bg-line text-slate', green: 'bg-emerald-600 text-white' }[tone];
  return <span className={`inline-flex items-center px-2 py-0.5 text-[11px] font-bold ${t}`}>{children}</span>;
};
const Field = ({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) => (
  <label className="block">
    <span className="text-sm font-bold">{label}</span>
    {hint && <span className="ms-2 text-xs text-steel">{hint}</span>}
    <div className="mt-1">{children}</div>
  </label>
);
const inputCls = 'block w-full border-2 border-line bg-white px-3 py-2 outline-none focus:border-ink';

/* ---------- main ---------- */
export function AdminDashboard({
  initialArticles,
  initialBreaking,
  authors,
  categories,
}: {
  initialArticles: Article[];
  initialBreaking: BreakingItem[];
  authors: Author[];
  categories: Category[];
}) {
  const [articles, setArticles] = useState<Article[]>(initialArticles);
  const [breaking, setBreaking] = useState<BreakingItem[]>(initialBreaking);
  const [loaded, setLoaded] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [tab, setTab] = useState<Tab>('articles');
  const [editing, setEditing] = useState<Article | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [query, setQuery] = useState('');
  const [catFilter, setCatFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [toast, setToast] = useState('');

  // restore local drafts
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const data = JSON.parse(saved) as { articles: Article[]; breaking: BreakingItem[] };
        setArticles(data.articles);
        setBreaking(data.breaking);
        setDirty(true);
      }
    } catch {
      /* storage unavailable */
    }
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (!loaded) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ articles, breaking }));
    } catch {
      /* ignore */
    }
  }, [articles, breaking, loaded]);

  const flash = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 2500);
  };
  const change = (fn: () => void) => {
    fn();
    setDirty(true);
  };

  const catName = (slug: string) => categories.find((c) => c.slug === slug)?.name ?? slug;
  const sorted = useMemo(() => [...articles].sort((a, b) => +new Date(b.publishedAt) - +new Date(a.publishedAt)), [articles]);
  const filtered = sorted.filter((a) => {
    if (catFilter !== 'all' && a.category !== catFilter) return false;
    if (statusFilter === 'published' && !a.published) return false;
    if (statusFilter === 'draft' && a.published) return false;
    if (statusFilter === 'featured' && !a.featured) return false;
    if (statusFilter === 'breaking' && !a.breaking) return false;
    if (query && !`${a.title} ${a.summary} ${a.slug}`.toLowerCase().includes(query.toLowerCase())) return false;
    return true;
  });
  const stats = {
    total: articles.length,
    published: articles.filter((a) => a.published).length,
    drafts: articles.filter((a) => !a.published).length,
    featured: articles.filter((a) => a.featured).length,
    breaking: breaking.filter((b) => b.active).length + articles.filter((a) => a.breaking).length,
  };

  function saveArticle(a: Article) {
    const errors: string[] = [];
    if (!a.title.trim()) errors.push('سرخي');
    if (!a.summary.trim()) errors.push('خلاصو');
    if (!/^[a-z0-9-]+$/.test(a.slug)) errors.push('slug (رڳو a-z, 0-9, -)');
    if (articles.some((x) => x.slug === a.slug && x.id !== a.id)) errors.push('slug اڳ ۾ موجود آهي');
    if (errors.length) {
      flash(`مهرباني ڪري درست ڪريو: ${errors.join('، ')}`);
      return;
    }
    const clean: Article = { ...a, imageAlt: a.imageAlt || a.title, updatedAt: isNew ? a.updatedAt : new Date().toISOString() };
    if (!clean.video?.url) delete clean.video;
    change(() => setArticles((list) => (isNew ? [clean, ...list] : list.map((x) => (x.id === a.id ? clean : x)))));
    setEditing(null);
    flash(isNew ? 'نئين خبر شامل ٿي وئي' : 'تبديليون محفوظ ٿي ويون');
  }

  return (
    <div className="pb-20">
      {/* top bar */}
      <header className="bg-ink text-white">
        <div className="container-x flex h-16 items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Logo height={44} />
            <div>
              <p className="font-display font-extrabold">ايڊمن ڊيش بورڊ</p>
              <p className="ltr text-end text-xs text-white/50">Content management (demo)</p>
            </div>
          </div>
          <Link href="/" className="inline-flex h-10 items-center gap-2 border border-white/20 px-3 text-sm hover:border-white" target="_blank">
            ويب سائيٽ ڏسو <Icon name="arrowLeft" size={14} />
          </Link>
        </div>
      </header>
      <div className="border-b-[3px] border-brand bg-brand-soft">
        <div className="container-x flex items-start gap-3 py-3 text-sm text-brand-dark">
          <Icon name="zap" size={16} className="mt-1 shrink-0" />
          <p>
            <b>ڊيمو ايڊمن:</b> تبديليون رڳو هن برائوزر ۾ محفوظ ٿين ٿيون. لائيو سائيٽ تي شايع ڪرڻ لاءِ “شايع ڪريو” ٽيب مان JSON فائلون ڊائونلوڊ ڪري <code className="ltr">data/</code> فولڊر ۾ رکو ۽ Vercel تي ڊيپلاءِ ڪريو — يا CMS ڳنڍيو (README).
          </p>
        </div>
      </div>

      <div className="container-x mt-6">
        {/* stats */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
          {[
            ['ڪل خبرون', stats.total],
            ['شايع ٿيل', stats.published],
            ['مسودا', stats.drafts],
            ['فيچرڊ', stats.featured],
            ['بريڪنگ', stats.breaking],
          ].map(([l, v]) => (
            <div key={l} className="border-t-4 border-ink bg-white p-4">
              <p className="text-sm text-steel">{l}</p>
              <p className="ltr text-end font-display text-3xl font-black">{v}</p>
            </div>
          ))}
        </div>

        {/* tabs */}
        <div className="no-scrollbar mt-6 flex overflow-x-auto border-b border-line" role="tablist">
          {(
            [
              ['articles', 'خبرون'],
              ['breaking', 'بريڪنگ نيوز'],
              ['authors', 'ليکڪ ۽ ڪيٽيگريز'],
              ['publish', 'شايع ڪريو / ايڪسپورٽ'],
            ] as [Tab, string][]
          ).map(([k, l]) => (
            <button
              key={k}
              type="button"
              role="tab"
              aria-selected={tab === k}
              onClick={() => setTab(k)}
              className={`h-12 shrink-0 px-5 font-bold ${tab === k ? 'border-b-[3px] border-brand text-ink' : 'text-steel hover:text-ink'}`}
            >
              {l}
              {k === 'publish' && dirty && <span className="ms-2 inline-block size-2 rounded-full bg-brand" />}
            </button>
          ))}
        </div>

        {/* ARTICLES */}
        {tab === 'articles' && (
          <section className="mt-5">
            <div className="flex flex-wrap items-center gap-3">
              <div className="relative min-w-56 flex-1">
                <Icon name="search" size={18} className="absolute top-1/2 start-3 -translate-y-1/2 text-steel" />
                <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="خبرون ڳوليو..." className={`${inputCls} ps-10`} aria-label="خبرون ڳوليو" />
              </div>
              <select value={catFilter} onChange={(e) => setCatFilter(e.target.value)} className={`${inputCls} !w-auto`} aria-label="ڪيٽيگري">
                <option value="all">سڀ ڪيٽيگريز</option>
                {categories.map((c) => (
                  <option key={c.slug} value={c.slug}>
                    {c.name}
                  </option>
                ))}
              </select>
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className={`${inputCls} !w-auto`} aria-label="اسٽيٽس">
                <option value="all">سڀ اسٽيٽس</option>
                <option value="published">شايع ٿيل</option>
                <option value="draft">مسودا</option>
                <option value="featured">فيچرڊ</option>
                <option value="breaking">بريڪنگ</option>
              </select>
              <button
                type="button"
                onClick={() => {
                  setIsNew(true);
                  setEditing(emptyArticle());
                }}
                className="inline-flex h-11 items-center gap-2 bg-brand px-5 font-bold text-white hover:bg-brand-dark"
              >
                <Icon name="plus" size={18} /> نئين خبر
              </button>
            </div>

            <p className="mt-4 text-sm text-steel">{filtered.length} خبرون</p>
            <ul className="mt-2 divide-y divide-line bg-white">
              {filtered.map((a) => (
                <li key={a.id} className="flex flex-col gap-3 p-4 md:flex-row md:items-center">
                  <div className="flex min-w-0 flex-1 items-start gap-4">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={a.image} alt="" className="aspect-video w-24 shrink-0 bg-mist object-cover" loading="lazy" />
                    <div className="min-w-0">
                      <p className="line-clamp-2 font-bold leading-7">{a.title || <span className="text-steel">(سرخي ناهي)</span>}</p>
                      <div className="mt-1 flex flex-wrap items-center gap-1.5 text-xs text-steel">
                        <Badge tone="dark">{catName(a.category)}</Badge>
                        {a.published ? <Badge tone="green">شايع</Badge> : <Badge>مسودو</Badge>}
                        {a.featured && <Badge tone="red">فيچرڊ {a.heroRank ? `#${a.heroRank}` : ''}</Badge>}
                        {a.breaking && <Badge tone="red">بريڪنگ</Badge>}
                        {a.video && <Badge>وڊيو</Badge>}
                        <span className="ms-1">{formatDateTime(a.publishedAt)}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex shrink-0 flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => change(() => setArticles((l) => l.map((x) => (x.id === a.id ? { ...x, published: !x.published } : x))))}
                      className="h-9 border border-line px-3 text-sm font-bold hover:border-ink"
                    >
                      {a.published ? 'اڻ شايع ڪريو' : 'شايع ڪريو'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setIsNew(false);
                        setEditing({ ...a });
                      }}
                      className="inline-flex h-9 items-center gap-1 bg-ink px-3 text-sm font-bold text-white hover:bg-brand"
                    >
                      <Icon name="edit" size={14} /> ايڊٽ
                    </button>
                    {a.published && (
                      <Link href={`/news/${a.slug}`} target="_blank" className="inline-flex size-9 items-center justify-center border border-line hover:border-ink" aria-label="لائيو ڏسو">
                        <Icon name="eye" size={16} />
                      </Link>
                    )}
                    {confirmDelete === a.id ? (
                      <span className="flex items-center gap-1 text-sm">
                        پڪ؟
                        <button
                          type="button"
                          className="h-9 bg-brand px-3 font-bold text-white"
                          onClick={() => {
                            change(() => setArticles((l) => l.filter((x) => x.id !== a.id)));
                            setConfirmDelete(null);
                            flash('خبر ڊليٽ ٿي وئي');
                          }}
                        >
                          ها
                        </button>
                        <button type="button" className="h-9 border border-line px-3" onClick={() => setConfirmDelete(null)}>
                          نه
                        </button>
                      </span>
                    ) : (
                      <button type="button" onClick={() => setConfirmDelete(a.id)} className="inline-flex size-9 items-center justify-center border border-line text-brand hover:border-brand" aria-label="ڊليٽ ڪريو">
                        <Icon name="trash" size={16} />
                      </button>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </section>
        )}

        {/* BREAKING */}
        {tab === 'breaking' && (
          <section className="mt-5 max-w-4xl">
            <p className="text-sm text-steel">ٽڪر ۾ رڳو “فعال” سرخيون نظر اينديون. خبرن ۾ “بريڪنگ” نشان لڳل خبرون پڻ پاڻمرادو شامل ٿين ٿيون.</p>
            <ul className="mt-4 space-y-3">
              {breaking.map((b) => (
                <li key={b.id} className="flex flex-col gap-2 bg-white p-4 md:flex-row md:items-center">
                  <input
                    value={b.text}
                    onChange={(e) => change(() => setBreaking((l) => l.map((x) => (x.id === b.id ? { ...x, text: e.target.value } : x))))}
                    className={`${inputCls} flex-1`}
                    aria-label="بريڪنگ سرخي"
                  />
                  <select
                    value={b.slug ?? ''}
                    onChange={(e) => change(() => setBreaking((l) => l.map((x) => (x.id === b.id ? { ...x, slug: e.target.value || undefined } : x))))}
                    className={`${inputCls} md:!w-56`}
                    aria-label="لنڪ ٿيل خبر"
                  >
                    <option value="">— ڪا لنڪ نه —</option>
                    {sorted.map((a) => (
                      <option key={a.id} value={a.slug}>
                        {a.title.slice(0, 50)}
                      </option>
                    ))}
                  </select>
                  <label className="flex items-center gap-2 text-sm font-bold">
                    <input type="checkbox" checked={b.active} onChange={() => change(() => setBreaking((l) => l.map((x) => (x.id === b.id ? { ...x, active: !x.active } : x))))} className="size-5 accent-brand" />
                    فعال
                  </label>
                  <button type="button" onClick={() => change(() => setBreaking((l) => l.filter((x) => x.id !== b.id)))} className="inline-flex size-10 items-center justify-center text-brand" aria-label="هٽايو">
                    <Icon name="trash" size={18} />
                  </button>
                </li>
              ))}
            </ul>
            <button
              type="button"
              onClick={() => change(() => setBreaking((l) => [...l, { id: `b${Date.now()}`, text: 'نئين بريڪنگ سرخي', active: true }]))}
              className="mt-4 inline-flex h-11 items-center gap-2 bg-ink px-5 font-bold text-white hover:bg-brand"
            >
              <Icon name="plus" size={18} /> بريڪنگ سرخي شامل ڪريو
            </button>
          </section>
        )}

        {/* AUTHORS & CATEGORIES */}
        {tab === 'authors' && (
          <section className="mt-5 grid gap-6 lg:grid-cols-2">
            <div className="bg-white p-5">
              <h2 className="text-lg">ليکڪ / رپورٽر</h2>
              <ul className="mt-3 divide-y divide-line">
                {authors.map((a) => (
                  <li key={a.id} className="flex items-center justify-between py-2.5">
                    <span className="font-bold">{a.name}</span>
                    <span className="text-sm text-steel">
                      {a.role} · <span className="ltr">{a.id}</span>
                    </span>
                  </li>
                ))}
              </ul>
              <p className="mt-3 text-xs text-steel">
                ليکڪ <code className="ltr">data/authors.json</code> ۾ شامل ڪريو.
              </p>
            </div>
            <div className="bg-white p-5">
              <h2 className="text-lg">ڪيٽيگريز</h2>
              <ul className="mt-3 divide-y divide-line">
                {categories.map((c) => (
                  <li key={c.slug} className="flex items-center justify-between py-2.5">
                    <span className="font-bold">{c.name}</span>
                    <span className="text-sm text-steel">
                      <span className="ltr">/category/{c.slug}</span> · {articles.filter((a) => a.category === c.slug).length}
                    </span>
                  </li>
                ))}
              </ul>
              <p className="mt-3 text-xs text-steel">
                ڪيٽيگريز <code className="ltr">data/categories.json</code> ۽ <code className="ltr">lib/types.ts</code> ۾.
              </p>
            </div>
          </section>
        )}

        {/* PUBLISH / EXPORT */}
        {tab === 'publish' && (
          <section className="mt-5 grid gap-6 lg:grid-cols-2">
            <div className="bg-white p-6">
              <h2 className="text-xl">لائيو سائيٽ تي شايع ڪرڻ جو طريقو</h2>
              <ol className="mt-4 list-decimal space-y-2 ps-5 font-naskh leading-8">
                <li>هيٺيان ٻئي JSON فائلون ڊائونلوڊ ڪريو.</li>
                <li>
                  پروجيڪٽ جي <code className="ltr">data/</code> فولڊر ۾ پراڻين فائلن جي جاءِ تي رکو.
                </li>
                <li>
                  نيون تصويرون <code className="ltr">public/images/news/</code> ۾ رکو.
                </li>
                <li>GitHub تي push ڪريو — Vercel پاڻمرادو نئون ورزن شايع ڪندو.</li>
              </ol>
              <div className="mt-6 flex flex-wrap gap-3">
                <button type="button" onClick={() => download('articles.json', articles)} className="inline-flex h-11 items-center gap-2 bg-brand px-5 font-bold text-white hover:bg-brand-dark">
                  <Icon name="download" size={18} /> articles.json
                </button>
                <button type="button" onClick={() => download('breaking.json', breaking)} className="inline-flex h-11 items-center gap-2 bg-ink px-5 font-bold text-white hover:bg-charcoal">
                  <Icon name="download" size={18} /> breaking.json
                </button>
              </div>
            </div>
            <div className="bg-white p-6">
              <h2 className="text-xl">مسودا ري سيٽ ڪريو</h2>
              <p className="mt-2 font-naskh leading-8 text-slate">هن برائوزر ۾ محفوظ سڀ تبديليون ختم ڪري، لائيو سائيٽ وارو اصل مواد واپس آڻيو.</p>
              <button
                type="button"
                onClick={() => {
                  localStorage.removeItem(STORAGE_KEY);
                  setArticles(initialArticles);
                  setBreaking(initialBreaking);
                  setDirty(false);
                  flash('اصل مواد واپس آيو');
                }}
                className="mt-4 inline-flex h-11 items-center gap-2 border-2 border-ink px-5 font-bold hover:bg-ink hover:text-white"
              >
                <Icon name="refresh" size={18} /> ري سيٽ
              </button>
            </div>
          </section>
        )}
      </div>

      {editing && <ArticleEditor article={editing} isNew={isNew} authors={authors} categories={categories} onCancel={() => setEditing(null)} onSave={saveArticle} />}

      {toast && (
        <div role="status" className="fixed inset-x-0 bottom-5 z-[80] mx-auto w-fit bg-ink px-5 py-3 font-bold text-white shadow-xl">
          {toast}
        </div>
      )}
    </div>
  );
}

/* ---------- editor drawer ---------- */
function ArticleEditor({
  article,
  isNew,
  authors,
  categories,
  onCancel,
  onSave,
}: {
  article: Article;
  isNew: boolean;
  authors: Author[];
  categories: Category[];
  onCancel: () => void;
  onSave: (a: Article) => void;
}) {
  const [a, setA] = useState<Article>(article);
  const [bodyText, setBodyText] = useState(bodyToText(article.body));
  const [tagsText, setTagsText] = useState((article.tags ?? []).join('، '));
  const [preview, setPreview] = useState<string | null>(null);
  const set = <K extends keyof Article>(k: K, v: Article[K]) => setA((x) => ({ ...x, [k]: v }));

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onCancel();
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [onCancel]);

  return (
    <div className="fixed inset-0 z-[70]" role="dialog" aria-modal="true" aria-label={isNew ? 'نئين خبر' : 'خبر ايڊٽ ڪريو'}>
      <button type="button" aria-label="بند ڪريو" className="absolute inset-0 bg-ink/70" onClick={onCancel} />
      <form
        onSubmit={(e) => {
          e.preventDefault();
          onSave({
            ...a,
            body: textToBody(bodyText),
            tags: tagsText
              .split(/[،,]/)
              .map((t) => t.trim())
              .filter(Boolean),
          });
        }}
        className="absolute inset-y-0 start-0 flex w-full max-w-3xl flex-col bg-white shadow-2xl"
      >
        <div className="flex items-center justify-between border-b-[3px] border-brand px-5 py-4">
          <h2 className="text-xl">{isNew ? 'نئين خبر' : 'خبر ايڊٽ ڪريو'}</h2>
          <button type="button" onClick={onCancel} className="inline-flex size-10 items-center justify-center" aria-label="بند ڪريو">
            <Icon name="close" size={22} />
          </button>
        </div>

        <div className="flex-1 space-y-5 overflow-y-auto p-5">
          <Field label="سرخي *">
            <input value={a.title} onChange={(e) => set('title', e.target.value)} className={`${inputCls} font-display text-lg font-bold`} required />
          </Field>
          <Field label="خلاصو *" hint="ڪارڊن ۽ SEO لاءِ (1–2 جملا)">
            <textarea value={a.summary} onChange={(e) => set('summary', e.target.value)} rows={2} className={`${inputCls} font-naskh leading-8`} required />
          </Field>
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="ڪيٽيگري">
              <select value={a.category} onChange={(e) => set('category', e.target.value as CategorySlug)} className={inputCls}>
                {categories.map((c) => (
                  <option key={c.slug} value={c.slug}>
                    {c.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="قسم">
              <select value={a.type} onChange={(e) => set('type', e.target.value as ArticleType)} className={inputCls}>
                <option value="news">خبر</option>
                <option value="video">وڊيو</option>
                <option value="opinion">راءِ / تجزيو</option>
                <option value="public-voice">عوام جو آواز</option>
              </select>
            </Field>
            <Field label="ليکڪ / رپورٽر">
              <select value={a.authorId} onChange={(e) => set('authorId', e.target.value)} className={inputCls}>
                {authors.map((au) => (
                  <option key={au.id} value={au.id}>
                    {au.name}
                  </option>
                ))}
              </select>
            </Field>
          </div>

          <Field label="مڪمل خبر" hint="پيراگراف وچ ۾ خالي لائين ڇڏيو · ## ذيلي سرخي · > اقتباس — حوالو">
            <textarea value={bodyText} onChange={(e) => setBodyText(e.target.value)} rows={10} className={`${inputCls} font-naskh leading-8`} />
          </Field>

          <div className="grid gap-4 sm:grid-cols-[1fr_180px]">
            <div className="space-y-3">
              <Field label="تصوير جو رستو" hint="public/ فولڊر مان">
                <input value={a.image} onChange={(e) => set('image', e.target.value)} dir="ltr" className={`${inputCls} text-start`} />
              </Field>
              <label className="inline-flex cursor-pointer items-center gap-2 border-2 border-dashed border-line px-4 py-2 text-sm font-bold hover:border-ink">
                <Icon name="upload" size={16} /> تصوير اپلوڊ ڪريو
                <input
                  type="file"
                  accept="image/*"
                  className="sr-only"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    setPreview(URL.createObjectURL(f));
                    set('image', `/images/news/${f.name.replace(/\s+/g, '-').toLowerCase()}`);
                  }}
                />
              </label>
              {preview && <p className="text-xs text-brand-dark">پريويو ڏيکاريل آهي. شايع ڪرڻ لاءِ هي فائل public/images/news/ ۾ رکو (يا CMS اسٽوريج ڳنڍيو).</p>}
              <Field label="تصوير جي وضاحت (alt)">
                <input value={a.imageAlt} onChange={(e) => set('imageAlt', e.target.value)} className={inputCls} />
              </Field>
            </div>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={preview ?? a.image} alt="" className="aspect-video w-full self-start bg-mist object-cover" />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Slug (URL)" hint="انگريزي، مثال: karachi-water-crisis">
              <input value={a.slug} onChange={(e) => set('slug', e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '-'))} dir="ltr" className={`${inputCls} text-start`} />
            </Field>
            <Field label="شايع ٿيڻ جي تاريخ ۽ وقت" hint="PKT">
              <input type="datetime-local" value={isoToLocal(a.publishedAt)} onChange={(e) => e.target.value && set('publishedAt', localToIso(e.target.value))} dir="ltr" className={inputCls} />
            </Field>
            <Field label="مقام / ضلعو">
              <input value={a.location ?? ''} onChange={(e) => set('location', e.target.value || undefined)} className={inputCls} />
            </Field>
            <Field label="ٽيگ" hint="ڪاما سان الڳ — سنڌي، اردو، English">
              <input value={tagsText} onChange={(e) => setTagsText(e.target.value)} className={inputCls} />
            </Field>
          </div>

          <fieldset className="border border-line p-4">
            <legend className="px-2 text-sm font-bold">وڊيو (اختياري)</legend>
            <div className="grid gap-4 sm:grid-cols-[1fr_140px]">
              <Field label="وڊيو URL" hint="YouTube / Facebook / .mp4">
                <input
                  value={a.video?.url ?? ''}
                  onChange={(e) => set('video', e.target.value ? { url: e.target.value, duration: a.video?.duration ?? '00:00' } : undefined)}
                  dir="ltr"
                  placeholder="https://www.youtube.com/watch?v=..."
                  className={`${inputCls} text-start`}
                />
              </Field>
              <Field label="دورانيو">
                <input
                  value={a.video?.duration ?? ''}
                  onChange={(e) => a.video && set('video', { ...a.video, duration: e.target.value })}
                  dir="ltr"
                  placeholder="05:30"
                  disabled={!a.video}
                  className={inputCls}
                />
              </Field>
            </div>
          </fieldset>

          <div className="flex flex-wrap items-center gap-x-6 gap-y-3 bg-mist p-4">
            <label className="flex items-center gap-2 font-bold">
              <input type="checkbox" checked={a.published} onChange={(e) => set('published', e.target.checked)} className="size-5 accent-brand" /> شايع ٿيل
            </label>
            <label className="flex items-center gap-2 font-bold">
              <input type="checkbox" checked={!!a.featured} onChange={(e) => set('featured', e.target.checked || undefined)} className="size-5 accent-brand" /> هيرو / فيچرڊ
            </label>
            {a.featured && (
              <label className="flex items-center gap-2 text-sm">
                ترتيب
                <input type="number" min={1} max={9} value={a.heroRank ?? 1} onChange={(e) => set('heroRank', Number(e.target.value))} className="w-16 border-2 border-line px-2 py-1" />
              </label>
            )}
            <label className="flex items-center gap-2 font-bold">
              <input type="checkbox" checked={!!a.breaking} onChange={(e) => set('breaking', e.target.checked || undefined)} className="size-5 accent-brand" /> بريڪنگ نيوز
            </label>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 border-t border-line p-4">
          <button type="button" onClick={onCancel} className="h-11 border-2 border-line px-5 font-bold hover:border-ink">
            منسوخ
          </button>
          <button type="submit" className="inline-flex h-11 items-center gap-2 bg-brand px-6 font-bold text-white hover:bg-brand-dark">
            <Icon name="check" size={18} /> محفوظ ڪريو
          </button>
        </div>
      </form>
    </div>
  );
}
