import type { Article } from '@/lib/types';
import { SectionHeading } from './SectionHeading';
import { VideoNewsCard } from './VideoNewsCard';

export function VideoSection({ videos }: { videos: Article[] }) {
  if (!videos.length) return null;
  const [featured, ...rest] = videos;
  return (
    <section aria-labelledby="sec-videos" className="relative overflow-hidden bg-ink py-12 text-white md:py-16">
      {/* logo-inspired red circle + ring + dots */}
      <div aria-hidden className="pointer-events-none absolute -top-40 -end-40 size-[28rem] rounded-full bg-brand/15 blur-2xl" />
      <div aria-hidden className="pointer-events-none absolute -bottom-48 -start-24 size-[30rem] rounded-full border border-brand/40" />
      <div aria-hidden className="dots pointer-events-none absolute top-0 start-0 h-48 w-80 text-white/10" />

      <div className="container-x relative">
        <SectionHeading id="sec-videos" title="وڊيو خبرون" href="/category/videos" linkLabel="سڀ وڊيوز ڏسو" dark />
        <div className="grid gap-8 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <VideoNewsCard article={featured} featured />
          </div>
          <div className="grid grid-cols-2 gap-x-5 gap-y-7 lg:col-span-5">
            {rest.slice(0, 4).map((v) => (
              <VideoNewsCard key={v.slug} article={v} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
