import { Breadcrumbs } from './Breadcrumbs';

export function PageHero({ title, subtitle, eyebrow, path }: { title: string; subtitle?: string; eyebrow?: string; path: string }) {
  return (
    <header className="relative overflow-hidden bg-ink text-white">
      <div aria-hidden className="absolute -top-24 -end-16 size-72 rounded-full bg-brand md:size-96" />
      <div aria-hidden className="absolute -top-36 -end-28 size-[24rem] rounded-full border border-brand/50 md:size-[30rem]" />
      <div aria-hidden className="dots absolute inset-y-0 start-0 w-1/2 text-white/[0.07]" />
      <div className="container-x relative py-12 md:py-16">
        <Breadcrumbs items={[{ name: 'هوم', href: '/' }, { name: title, href: path }]} dark />
        {eyebrow && <p className="ltr mt-5 text-end text-sm tracking-[0.25em] text-white/50 uppercase md:text-start">{eyebrow}</p>}
        <h1 className="mt-3 max-w-3xl text-[2.2rem] leading-[1.4] font-black md:text-[3.2rem]">{title}</h1>
        {subtitle && <p className="mt-4 max-w-2xl font-naskh text-lg leading-9 text-white/75">{subtitle}</p>}
      </div>
    </header>
  );
}
