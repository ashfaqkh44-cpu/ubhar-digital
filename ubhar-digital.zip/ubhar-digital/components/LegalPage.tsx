import { PageHero } from './PageHero';

export function LegalPage({
  title,
  eyebrow,
  path,
  intro,
  sections,
  updated = '18 نومبر 2026',
}: {
  title: string;
  eyebrow: string;
  path: string;
  intro: string;
  sections: { heading: string; body: string[] }[];
  updated?: string;
}) {
  return (
    <>
      <PageHero title={title} eyebrow={eyebrow} path={path} />
      <div className="container-x py-12 md:py-16">
        <div className="prose-sd mx-auto max-w-3xl">
          <p className="text-sm text-steel">آخري تازه ڪاري: {updated}</p>
          <p>{intro}</p>
          {sections.map((s) => (
            <section key={s.heading}>
              <h2>{s.heading}</h2>
              {s.body.map((p, i) => (
                <p key={i}>{p}</p>
              ))}
            </section>
          ))}
          <p className="bg-mist p-4 text-base text-slate">نوٽ: هي متن ابتدائي مسودو آهي. شايع ڪرڻ کان اڳ قانوني صلاحڪار کان جائزو وٺرايو.</p>
        </div>
      </div>
    </>
  );
}
