'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Icon } from './Icon';
import { OPEN_SEARCH_EVENT } from './SearchButton';
import type { SearchHit } from '@/lib/types';
import { formatDate } from '@/lib/date';

const SUGGESTIONS = ['سنڌ', 'ڪراچي', 'تعليم', 'پاڻي', 'ثقافت', 'کراچی', 'Education', 'Karachi'];

export function SearchModal() {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [hits, setHits] = useState<SearchHit[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();
  const pathname = usePathname();

  const close = useCallback(() => setOpen(false), []);

  // open via custom event, "/" or Ctrl/⌘+K
  useEffect(() => {
    const onOpen = () => setOpen(true);
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const typing = target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable);
      if ((e.key === '/' && !typing) || ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k')) {
        e.preventDefault();
        setOpen(true);
      }
    };
    window.addEventListener(OPEN_SEARCH_EVENT, onOpen);
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener(OPEN_SEARCH_EVENT, onOpen);
      window.removeEventListener('keydown', onKey);
    };
  }, []);

  useEffect(() => close(), [pathname, close]);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const t = setTimeout(() => inputRef.current?.focus(), 30);
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && close();
    window.addEventListener('keydown', onKey);
    return () => {
      clearTimeout(t);
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', onKey);
    };
  }, [open, close]);

  // debounced live search
  useEffect(() => {
    const term = q.trim();
    if (!term) {
      setHits([]);
      setSearched(false);
      return;
    }
    const ctrl = new AbortController();
    setLoading(true);
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(term)}&limit=8`, { signal: ctrl.signal });
        const data = (await res.json()) as { results: SearchHit[] };
        setHits(data.results);
        setSearched(true);
      } catch {
        /* aborted */
      } finally {
        if (!ctrl.signal.aborted) setLoading(false);
      }
    }, 220);
    return () => {
      clearTimeout(t);
      ctrl.abort();
    };
  }, [q]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[70]" role="dialog" aria-modal="true" aria-label="خبرون ڳوليو">
      <button type="button" aria-label="بند ڪريو" onClick={close} className="absolute inset-0 animate-fade-in bg-ink/85 backdrop-blur-sm" />
      <div className="relative mx-auto mt-0 flex max-h-full w-full max-w-3xl animate-fade-in flex-col bg-white shadow-2xl md:mt-[8vh] md:max-h-[80vh]">
        <form
          role="search"
          onSubmit={(e) => {
            e.preventDefault();
            if (q.trim()) router.push(`/search?q=${encodeURIComponent(q.trim())}`);
          }}
          className="flex items-center gap-3 border-b-[3px] border-brand px-4 md:px-6"
        >
          <Icon name="search" size={24} className="shrink-0 text-brand" />
          <label htmlFor="search-modal-input" className="sr-only">
            ڳولا
          </label>
          <input
            ref={inputRef}
            id="search-modal-input"
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="سنڌي، اردو يا English ۾ ڳوليو..."
            autoComplete="off"
            className="h-16 min-w-0 flex-1 bg-transparent font-display text-lg font-semibold outline-none placeholder:font-normal placeholder:text-steel md:h-20 md:text-xl"
          />
          {loading && <span className="size-5 shrink-0 animate-spin rounded-full border-2 border-line border-t-brand" aria-label="ڳولي رهيا آهيون" />}
          <button type="button" onClick={close} aria-label="بند ڪريو" className="inline-flex size-10 shrink-0 items-center justify-center text-slate hover:text-brand">
            <Icon name="close" size={22} />
          </button>
        </form>

        <div className="overflow-y-auto px-4 py-5 md:px-6">
          {!q.trim() && (
            <div>
              <p className="text-sm font-bold text-steel">مشهور موضوع</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {SUGGESTIONS.map((s) => (
                  <button key={s} type="button" onClick={() => setQ(s)} className="border border-line px-3 py-1.5 text-sm font-semibold hover:border-brand hover:text-brand">
                    {s}
                  </button>
                ))}
              </div>
              <p className="mt-6 hidden text-xs text-steel md:block">
                ڪي بورڊ: <kbd className="ltr border border-line px-1.5">/</kbd> يا <kbd className="ltr border border-line px-1.5">Ctrl K</kbd> ڳولا کولي ٿو، <kbd className="ltr border border-line px-1.5">Esc</kbd> بند ڪري ٿو.
              </p>
            </div>
          )}

          {q.trim() && searched && hits.length === 0 && !loading && (
            <div className="py-10 text-center">
              <div className="mx-auto flex size-16 items-center justify-center rounded-full bg-mist text-steel">
                <Icon name="search" size={28} />
              </div>
              <p className="mt-4 text-lg font-bold">“{q}” لاءِ ڪو به نتيجو نه مليو</p>
              <p className="mt-1 text-sm text-steel">ٻيا لفظ آزمايو يا اسپيلنگ چيڪ ڪريو.</p>
            </div>
          )}

          {hits.length > 0 && (
            <>
              <ul className="divide-y divide-line">
                {hits.map((h) => (
                  <li key={h.slug}>
                    <Link href={`/news/${h.slug}`} onClick={close} className="group flex gap-4 py-3">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={h.image} alt="" width={96} height={54} loading="lazy" className="aspect-video w-24 shrink-0 bg-mist object-cover" />
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-brand">{h.categoryName}</p>
                        <p className="leading-[1.7] font-bold group-hover:text-brand">{h.title}</p>
                        <p className="text-xs text-steel">{formatDate(h.publishedAt)}</p>
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
              <Link
                href={`/search?q=${encodeURIComponent(q.trim())}`}
                onClick={close}
                className="mt-4 flex h-12 items-center justify-center gap-2 bg-ink font-bold text-white hover:bg-brand"
              >
                سڀ نتيجا ڏسو <Icon name="arrowLeft" size={16} />
              </Link>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
