/**
 * Language selector. Sindhi is live; Urdu and English are prepared in the
 * routing/content model for a future phase and are shown as "coming soon".
 * Uses <details> so it works without JavaScript.
 */
export function LanguageSelector() {
  return (
    <details className="group relative">
      <summary className="flex cursor-pointer list-none items-center gap-1 px-2 py-1 text-white/80 hover:text-white [&::-webkit-details-marker]:hidden">
        <span>سنڌي</span>
        <svg width="10" height="10" viewBox="0 0 10 10" aria-hidden className="transition-transform group-open:rotate-180">
          <path d="M1 3l4 4 4-4" stroke="currentColor" strokeWidth="1.5" fill="none" />
        </svg>
      </summary>
      <ul className="absolute end-0 top-full z-50 mt-1 w-40 border border-white/10 bg-charcoal py-1 text-sm shadow-xl">
        <li>
          <span className="flex items-center justify-between px-3 py-2 text-white">
            سنڌي <span className="size-1.5 rounded-full bg-brand" />
          </span>
        </li>
        <li>
          <span className="flex items-center justify-between px-3 py-2 text-white/40" title="جلد اچي رهيو آهي">
            اردو <small>جلد</small>
          </span>
        </li>
        <li>
          <span className="ltr flex items-center justify-between px-3 py-2 text-white/40" title="Coming soon">
            English <small>soon</small>
          </span>
        </li>
      </ul>
    </details>
  );
}
