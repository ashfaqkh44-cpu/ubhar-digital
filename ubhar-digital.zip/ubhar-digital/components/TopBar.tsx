import { TodayDate } from './TodayDate';
import { SocialLinks } from './SocialLinks';
import { SearchButton } from './SearchButton';
import { LanguageSelector } from './LanguageSelector';

export function TopBar() {
  return (
    <div className="border-b border-white/10 bg-ink text-[13px] text-white/70">
      <div className="container-x flex h-9 items-center justify-between gap-4">
        <TodayDate />
        <div className="flex items-center gap-1">
          <SocialLinks size={14} className="hidden sm:flex" />
          <span className="mx-1 hidden h-4 w-px bg-white/15 sm:block" />
          <LanguageSelector />
          <SearchButton size={16} className="inline-flex size-8 text-white/70 hover:text-white" />
        </div>
      </div>
    </div>
  );
}
