import Link from 'next/link';
import { Logo } from './Logo';
import { SocialLinks } from './SocialLinks';
import { Icon } from './Icon';
import { categories } from '@/lib/categories';
import { footerNav, site } from '@/lib/site';

export function Footer() {
  const year = new Date().getFullYear();
  const sections = categories.filter((c) => c.slug !== 'public-voice');
  return (
    <footer className="relative overflow-hidden bg-ink text-white">
      <div aria-hidden className="absolute -top-40 -start-40 size-[26rem] rounded-full border border-brand/30" />
      <div aria-hidden className="dots absolute bottom-0 end-0 h-56 w-96 text-white/[0.06]" />
      <div className="h-1.5 bg-brand" />
      <div className="container-x relative grid gap-10 py-12 md:grid-cols-2 md:py-16 lg:grid-cols-12">
        <div className="lg:col-span-4">
          <Logo variant="tagline" height={130} />
          <p className="mt-5 font-display text-xl font-extrabold">{site.slogan}</p>
          <p className="mt-3 max-w-sm font-naskh leading-8 text-white/60">
            اُڀار ڊجيٽل هڪ آزاد ڊجيٽل ميڊيا پليٽ فارم آهي، جيڪو سنڌ ۽ دنيا جون خبرون، عوامي مسئلا ۽ عام ماڻهوءَ جو آواز سامهون آڻي ٿو.
          </p>
        </div>

        <nav aria-label="سيڪشن" className="lg:col-span-3">
          <h2 className="mb-4 text-base text-white/50">سيڪشن</h2>
          <ul className="grid grid-cols-2 gap-x-4 gap-y-2.5">
            {sections.map((c) => (
              <li key={c.slug}>
                <Link href={`/category/${c.slug}`} className="text-white/85 hover:text-brand">
                  {c.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <nav aria-label="اُڀار" className="lg:col-span-2">
          <h2 className="mb-4 text-base text-white/50">اُڀار</h2>
          <ul className="space-y-2.5">
            {footerNav.map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="text-white/85 hover:text-brand">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="lg:col-span-3">
          <h2 className="mb-4 text-base text-white/50">رابطو</h2>
          <ul className="space-y-3 text-white/85">
            <li className="flex items-center gap-2">
              <Icon name="mail" size={16} className="text-brand" />
              <a href={`mailto:${site.contact.email}`} className="ltr hover:text-brand">
                {site.contact.email}
              </a>
            </li>
            <li className="flex items-center gap-2">
              <Icon name="whatsapp" size={16} className="text-brand" />
              <a href={`https://wa.me/${site.contact.whatsapp}`} target="_blank" rel="noopener noreferrer" className="ltr hover:text-brand">
                {site.contact.phone}
              </a>
            </li>
            <li className="flex items-center gap-2">
              <Icon name="pin" size={16} className="text-brand" />
              {site.contact.address}
            </li>
          </ul>
          <SocialLinks size={18} boxed className="mt-6 flex-wrap gap-2" itemClassName="text-white" />
          <p className="ltr mt-3 text-end text-sm text-white/40">@UBHARdigital</p>
        </div>
      </div>

      <div className="relative border-t border-white/10">
        <div className="container-x flex flex-col items-center justify-between gap-2 py-5 text-sm text-white/50 md:flex-row">
          <p className="ltr">© {year} UBHAR Digital — All Rights Reserved</p>
          {site.showSampleNotice ? (
            <p className="text-center text-xs text-white/40">ڊولپمينٽ پريويو: سائيٽ تي ڏنل سمورو مواد نموني طور آهي ۽ تبديل ٿيڻ لائق آهي.</p>
          ) : (
            <p>{site.sloganShort}</p>
          )}
        </div>
      </div>
    </footer>
  );
}
