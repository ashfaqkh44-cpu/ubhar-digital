import { formatDate, formatDateTime } from '@/lib/date';
import { Icon } from './Icon';

export function TimeStamp({
  iso,
  withTime = true,
  icon = true,
  className = '',
}: {
  iso: string;
  withTime?: boolean;
  icon?: boolean;
  className?: string;
}) {
  return (
    <time dateTime={iso} className={`inline-flex items-center gap-1.5 text-[13px] whitespace-nowrap text-steel ${className}`}>
      {icon && <Icon name="clock" size={13} />}
      {withTime ? formatDateTime(iso) : formatDate(iso)}
    </time>
  );
}
