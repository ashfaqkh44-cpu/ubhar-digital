/**
 * Lightweight inline SVG icon set (Lucide-style strokes + brand glyphs).
 * Inline SVG keeps the JavaScript bundle at zero for icons — important on slow mobile networks.
 */
import type { ReactNode, SVGProps } from 'react';

type StrokeIcon = { kind: 'stroke'; d: string; extra?: ReactNode };
type FillIcon = { kind: 'fill'; d: string };

const icons = {
  search: { kind: 'stroke', d: 'm21 21-4.3-4.3', extra: <circle cx="11" cy="11" r="7.5" /> },
  menu: { kind: 'stroke', d: 'M4 6h16M4 12h16M4 18h16' },
  close: { kind: 'stroke', d: 'M18 6 6 18M6 6l12 12' },
  play: { kind: 'fill', d: 'M8 5.14v13.72a1 1 0 0 0 1.52.85l10.9-6.86a1 1 0 0 0 0-1.7L9.52 4.29A1 1 0 0 0 8 5.14Z' },
  clock: { kind: 'stroke', d: 'M12 7v5l3 2', extra: <circle cx="12" cy="12" r="9" /> },
  chevronLeft: { kind: 'stroke', d: 'm15 18-6-6 6-6' },
  chevronRight: { kind: 'stroke', d: 'm9 18 6-6-6-6' },
  arrowLeft: { kind: 'stroke', d: 'M19 12H5M12 19l-7-7 7-7' },
  link: {
    kind: 'stroke',
    d: 'M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71',
  },
  check: { kind: 'stroke', d: 'M20 6 9 17l-5-5' },
  eye: { kind: 'stroke', d: 'M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z', extra: <circle cx="12" cy="12" r="3" /> },
  mail: { kind: 'stroke', d: 'm22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7', extra: <rect x="2" y="4" width="20" height="16" rx="2" /> },
  phone: {
    kind: 'stroke',
    d: 'M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92Z',
  },
  pin: { kind: 'stroke', d: 'M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z', extra: <circle cx="12" cy="10" r="3" /> },
  user: { kind: 'stroke', d: 'M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2', extra: <circle cx="12" cy="7" r="4" /> },
  message: { kind: 'stroke', d: 'M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z' },
  globe: {
    kind: 'stroke',
    d: 'M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z',
    extra: <circle cx="12" cy="12" r="10" />,
  },
  megaphone: { kind: 'stroke', d: 'm3 11 18-5v12L3 14v-3zM11.6 16.8a3 3 0 1 1-5.8-1.6' },
  zap: { kind: 'fill', d: 'M13 2 3 14h9l-1 8 10-12h-9l1-8z' },
  video: { kind: 'stroke', d: 'm22 8-6 4 6 4V8Z', extra: <rect x="2" y="6" width="14" height="12" rx="2" /> },
  trending: { kind: 'stroke', d: 'M22 7 13.5 15.5 8.5 10.5 2 17M16 7h6v6' },
  plus: { kind: 'stroke', d: 'M12 5v14M5 12h14' },
  edit: { kind: 'stroke', d: 'M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z' },
  trash: { kind: 'stroke', d: 'M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2' },
  download: { kind: 'stroke', d: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3' },
  upload: { kind: 'stroke', d: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12' },
  refresh: { kind: 'stroke', d: 'M3 12a9 9 0 0 1 15.74-6L21 8M21 3v5h-5M21 12a9 9 0 0 1-15.74 6L3 16M8 16H3v5' },
  star: { kind: 'stroke', d: 'm12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z' },
  quote: {
    kind: 'fill',
    d: 'M10 11H6.2c.2-2.4 1.6-3.9 3.8-4.4V4C6 4.5 3 7.4 3 12.3V20h7v-9Zm11 0h-3.8c.2-2.4 1.6-3.9 3.8-4.4V4c-4 .5-7 3.4-7 8.3V20h7v-9Z',
  },
  facebook: {
    kind: 'fill',
    d: 'M14 13.5h2.5l1-4H14v-2c0-1.03 0-2 2-2h1.5V2.14C17.17 2.1 15.95 2 14.64 2 11.93 2 10 3.66 10 6.7v2.8H7v4h3V22h4v-8.5Z',
  },
  youtube: {
    kind: 'fill',
    d: 'M23.5 6.19a3.02 3.02 0 0 0-2.12-2.14C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.5A3.02 3.02 0 0 0 .5 6.19C0 8.07 0 12 0 12s0 3.93.5 5.81a3.02 3.02 0 0 0 2.12 2.14c1.87.5 9.38.5 9.38.5s7.5 0 9.38-.5a3.02 3.02 0 0 0 2.12-2.14C24 15.93 24 12 24 12s0-3.93-.5-5.81ZM9.55 15.57V8.43L15.82 12l-6.27 3.57Z',
  },
  instagram: {
    kind: 'stroke',
    d: 'M17.5 6.5h.01',
    extra: (
      <>
        <rect x="2" y="2" width="20" height="20" rx="5" />
        <circle cx="12" cy="12" r="4" />
      </>
    ),
  },
  tiktok: {
    kind: 'fill',
    d: 'M12.53.02C13.84 0 15.14.01 16.44 0c.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07Z',
  },
  x: {
    kind: 'fill',
    d: 'M18.9 1.15h3.68l-8.04 9.19L24 22.85h-7.41l-5.8-7.58-6.64 7.58H.47l8.6-9.83L0 1.15h7.59l5.24 6.93 6.07-6.93Zm-1.29 19.5h2.04L6.49 3.24H4.3L17.61 20.65Z',
  },
  whatsapp: {
    kind: 'fill',
    d: 'M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.16-.17.2-.35.22-.64.08-.3-.15-1.26-.46-2.39-1.48-.88-.79-1.48-1.76-1.65-2.06-.17-.3-.02-.46.13-.6.13-.14.3-.35.45-.52.15-.18.2-.3.3-.5.1-.2.05-.37-.03-.52-.07-.15-.67-1.61-.92-2.2-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.48 0 1.46 1.07 2.88 1.21 3.07.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.7.63.71.22 1.36.19 1.87.12.57-.09 1.76-.72 2-1.41.25-.7.25-1.29.18-1.42-.08-.12-.27-.2-.57-.34m-5.42 7.4h-.01a9.87 9.87 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.86 9.86 0 0 1-1.51-5.26c0-5.45 4.44-9.88 9.89-9.88 2.64 0 5.12 1.03 6.99 2.9a9.83 9.83 0 0 1 2.89 6.99c0 5.45-4.44 9.88-9.88 9.88m8.41-18.3A11.82 11.82 0 0 0 12.05 0C5.5 0 .16 5.34.16 11.89c0 2.1.55 4.14 1.59 5.95L.06 24l6.3-1.65a11.88 11.88 0 0 0 5.69 1.45h.01c6.55 0 11.89-5.34 11.89-11.89a11.82 11.82 0 0 0-3.48-8.41Z',
  },
} satisfies Record<string, StrokeIcon | FillIcon>;

export type IconName = keyof typeof icons;

export function Icon({
  name,
  size = 20,
  strokeWidth = 2,
  ...rest
}: { name: IconName; size?: number; strokeWidth?: number } & SVGProps<SVGSVGElement>) {
  const icon = icons[name] as StrokeIcon | FillIcon;
  const common = {
    width: size,
    height: size,
    viewBox: '0 0 24 24',
    'aria-hidden': true,
    focusable: false,
    ...rest,
  };
  if (icon.kind === 'fill') {
    return (
      <svg {...common} fill="currentColor">
        <path d={icon.d} />
      </svg>
    );
  }
  return (
    <svg
      {...common}
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {icon.extra}
      <path d={icon.d} />
    </svg>
  );
}
