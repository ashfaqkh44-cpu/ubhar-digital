'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { Icon } from './Icon';
import { footerNav, mainNav, site, socialList } from '@/lib/site';
import { isActive } from './MainNav';
import { OPEN_SEARCH_EVENT } from './SearchButton';

export function MobileNavigation() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname() ?? '/';
  const closeRef = useRef<HTMLButtonElement>(null);

  // Close when the route changes
  useEffect(() => setOpen(false), [pathname]);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', onKey);
    };
  }, [open]);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="مينيو کوليو"
        aria-expanded={open}
        aria-controls="mobile-menu"
        className="inline-flex size-11 items-center justify-center text-white hover:text-brand lg:hidden"
      >
        <Icon name="menu" size={26} />
      </button>

      {open && (
        <div className="fixed inset-0 z-[60] lg:hidden" role="dialog" aria-modal="true" aria-label="مينيو" id="mobile-menu">
          <button
            type="button"
            aria-label="مينيو بند ڪريو"
            className="absolute inset-0 animate-fade-in bg-black/70"
            onClick={() => setOpen(false)}
          />
          <div className="absolute inset-y-0 start-0 flex w-[86%] max-w-sm animate-slide-in flex-col overflow-y-auto bg-ink text-white shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
              <span className="font-display text-lg font-extrabold">
                {site.nameSd}
                <span className="ms-2 inline-block size-2 rounded-full bg-brand" />
              </span>
              <button
                ref={closeRef}
                type="button"
                onClick={() => setOpen(false)}
                aria-label="بند ڪريو"
                className="inline-flex size-10 items-center justify-center text-white/80 hover:text-brand"
              >
                <Icon name="close" size={24} />
              </button>
            </div>

            <button
              type="button"
              onClick={() => {
                setOpen(false);
                window.dispatchEvent(new CustomEvent(OPEN_SEARCH_EVENT));
              }}
              className="mx-5 mt-5 flex items-center gap-3 border border-white/15 bg-white/5 px-4 py-3 text-start text-white/60"
            >
              <Icon name="search" size={18} />
              خبرون ڳوليو...
            </button>

            <nav aria-label="موبائل مينيو" className="mt-4 flex-1">
              <ul>
                {mainNav.map((item) => {
                  const active = isActive(pathname, item.href);
                  return (
                    <li key={item.href}>
                      <Link
                        href={item.href}
                        aria-current={active ? 'page' : undefined}
                        className={`flex items-center justify-between border-b border-white/5 px-5 py-3.5 text-[17px] font-semibold ${
                          active ? 'border-s-4 border-s-brand bg-white/5 text-brand' : 'text-white hover:bg-white/5'
                        }`}
                      >
                        {item.label}
                        <Icon name="chevronLeft" size={18} className="text-white/30" />
                      </Link>
                    </li>
                  );
                })}
              </ul>
              <ul className="grid grid-cols-2 gap-x-4 gap-y-2 px-5 py-5 text-sm text-white/60">
                {footerNav.map((item) => (
                  <li key={item.href}>
                    <Link href={item.href} className="hover:text-white">
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>

            <div className="border-t border-white/10 px-5 py-5">
              <p className="mb-3 text-sm text-white/50">اسان کي فالو ڪريو</p>
              <ul className="flex gap-2">
                {socialList.map((s) => (
                  <li key={s.key}>
                    <a
                      href={site.social[s.key]}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={s.label}
                      className="inline-flex size-11 items-center justify-center bg-white/5 text-white hover:bg-brand"
                    >
                      <Icon name={s.key} size={18} />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
