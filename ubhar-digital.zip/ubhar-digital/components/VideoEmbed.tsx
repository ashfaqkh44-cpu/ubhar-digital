'use client';

import Image from 'next/image';
import { useState } from 'react';
import { Icon } from './Icon';
import type { VideoInfo } from '@/lib/types';

type Parsed = { kind: 'youtube'; id: string } | { kind: 'facebook'; url: string } | { kind: 'file'; url: string };

export function parseVideoUrl(url: string): Parsed {
  const yt = url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/|live\/)|youtu\.be\/)([\w-]{11})/);
  if (yt) return { kind: 'youtube', id: yt[1] };
  if (/facebook\.com|fb\.watch/.test(url)) return { kind: 'facebook', url };
  return { kind: 'file', url };
}

/**
 * Video player supporting YouTube, Facebook and uploaded files.
 * Third-party players load only after the reader presses play (saves data on mobile).
 */
export function VideoEmbed({ video, poster, title }: { video: VideoInfo; poster: string; title: string }) {
  const [playing, setPlaying] = useState(false);
  const parsed = parseVideoUrl(video.url);

  if (parsed.kind === 'file') {
    return (
      <div className="relative aspect-video bg-ink">
        <video controls preload="none" poster={poster} className="size-full" playsInline>
          <source src={parsed.url} />
          توهان جو برائوزر وڊيو هلائي نٿو سگهي.
        </video>
      </div>
    );
  }

  if (playing) {
    const src =
      parsed.kind === 'youtube'
        ? `https://www.youtube-nocookie.com/embed/${parsed.id}?autoplay=1&rel=0`
        : `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(parsed.url)}&show_text=false&autoplay=true`;
    return (
      <div className="relative aspect-video bg-ink">
        <iframe
          src={src}
          title={title}
          className="absolute inset-0 size-full"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
        />
      </div>
    );
  }

  return (
    <button type="button" onClick={() => setPlaying(true)} className="group relative block aspect-video w-full overflow-hidden bg-ink" aria-label={`وڊيو هلايو: ${title}`}>
      <Image src={poster} alt="" fill sizes="(min-width:1024px) 800px, 100vw" className="object-cover opacity-80 transition-opacity group-hover:opacity-100" priority />
      <span className="absolute inset-0 m-auto flex size-20 items-center justify-center rounded-full bg-brand text-white shadow-[0_0_0_10px_rgba(229,9,32,.25)] transition-transform group-hover:scale-110">
        <Icon name="play" size={34} className="-me-1" />
      </span>
      <span className="ltr absolute bottom-3 end-3 bg-ink/90 px-2 py-0.5 text-sm font-semibold text-white">{video.duration}</span>
    </button>
  );
}
