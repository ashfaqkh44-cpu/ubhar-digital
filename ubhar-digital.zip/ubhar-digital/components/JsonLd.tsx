/** Renders structured data. Content is JSON-serialised server-side; "<" is escaped to prevent script injection. */
export function JsonLd({ data }: { data: unknown }) {
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, '\\u003c') }} />;
}
