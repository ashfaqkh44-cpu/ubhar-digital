import Link from 'next/link';
import { Icon } from './Icon';

export function Breadcrumbs({ items, dark = false }: { items: { name: string; href: string }[]; dark?: boolean }) {
  return (
    <nav aria-label="بريڊ ڪرمب" className={`text-sm ${dark ? 'text-white/60' : 'text-steel'}`}>
      <ol className="flex flex-wrap items-center gap-1.5">
        {items.map((it, i) => {
          const last = i === items.length - 1;
          return (
            <li key={it.href} className="flex min-w-0 items-center gap-1.5">
              {last ? (
                <span aria-current="page" className={`line-clamp-1 font-semibold ${dark ? 'text-white' : 'text-ink'}`}>
                  {it.name}
                </span>
              ) : (
                <>
                  <Link href={it.href} className="hover:text-brand">
                    {it.name}
                  </Link>
                  <Icon name="chevronLeft" size={14} />
                </>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
