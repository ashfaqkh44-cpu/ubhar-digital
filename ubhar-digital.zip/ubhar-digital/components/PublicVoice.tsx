import Link from 'next/link';
import type { Article } from '@/lib/types';
import { articleHref } from '@/lib/content';
import { TimeStamp } from './TimeStamp';
import { Icon } from './Icon';
import { site } from '@/lib/site';

export function PublicVoiceCard({ article: a }: { article: Article }) {
  return (
    <article className="reveal group relative flex flex-col border border-line border-t-4 border-t-brand bg-white p-5 transition-shadow hover:shadow-[0_12px_30px_-18px_rgba(11,11,15,.45)]">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="slant bg-ink py-0.5 text-xs font-bold text-white">{a.voiceType ?? 'عوامي رپورٽ'}</span>
        {a.location && (
          <span className="inline-flex items-center gap-1 text-xs font-semibold text-slate">
            <Icon name="pin" size={13} className="text-brand" />
            {a.location}
          </span>
        )}
      </div>
      <h3 className="mt-3 text-lg leading-[1.65]">
        <Link href={articleHref(a)} className="headline-link after:absolute after:inset-0 after:content-['']">
          {a.title}
        </Link>
      </h3>
      <p className="mt-2 line-clamp-2 font-naskh text-[15px] leading-8 text-slate">{a.summary}</p>
      <TimeStamp iso={a.publishedAt} withTime={false} className="mt-auto pt-3" />
    </article>
  );
}

export function PublicVoice({ items }: { items: Article[] }) {
  return (
    <section aria-labelledby="sec-voice" className="container-x py-12 md:py-16">
      <div className="grid gap-6 lg:grid-cols-12 lg:gap-8">
        <div className="relative overflow-hidden bg-ink p-7 text-white md:p-9 lg:col-span-4">
          <div aria-hidden className="absolute -bottom-20 -end-20 size-64 rounded-full bg-brand" />
          <div aria-hidden className="absolute -bottom-28 -end-28 size-80 rounded-full border border-brand/50" />
          <div aria-hidden className="dots absolute top-0 start-0 h-32 w-40 text-white/10" />
          <div className="relative">
            <Icon name="megaphone" size={34} className="text-brand" />
            <h2 id="sec-voice" className="mt-4 text-[2rem] leading-tight font-black md:text-[2.4rem]">
              عوام جو آواز
            </h2>
            <p className="mt-4 font-display text-xl leading-relaxed font-extrabold">
              خبر، نظر ۽ <span className="bg-brand px-1.5">آواز عوام جو.</span>
            </p>
            <p className="mt-4 font-naskh leading-8 text-white/70">
              توهان جي علائقي جو مسئلو، شڪايت يا ڪا سٺي ڪهاڻي — اُڀار ان کي سڀني تائين پهچائيندو. تصديق کانپوءِ اسان توهان جي رپورٽ شايع ڪنداسين.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link href="/contact?subject=public-voice" className="inline-flex h-12 items-center gap-2 bg-white px-5 font-bold text-ink transition-colors hover:bg-brand hover:text-white">
                پنهنجي رپورٽ موڪليو
                <Icon name="arrowLeft" size={16} />
              </Link>
              <a
                href={`https://wa.me/${site.contact.whatsapp}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex h-12 items-center gap-2 border border-white/25 px-4 font-bold text-white hover:border-white"
              >
                <Icon name="whatsapp" size={18} />
                واٽس ايپ
              </a>
            </div>
          </div>
        </div>

        <div className="lg:col-span-8">
          <div className="mb-5 flex items-center justify-between">
            <p className="text-sm font-bold text-slate">شهرين جون تازيون رپورٽون</p>
            <Link href="/category/public-voice" className="inline-flex items-center gap-1 text-sm font-bold text-slate hover:text-brand">
              سڀ ڏسو <Icon name="arrowLeft" size={16} />
            </Link>
          </div>
          <div className="grid gap-5 sm:grid-cols-2">
            {items.slice(0, 4).map((a) => (
              <PublicVoiceCard key={a.slug} article={a} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
