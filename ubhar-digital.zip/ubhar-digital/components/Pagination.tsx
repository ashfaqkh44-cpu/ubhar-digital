import Link from 'next/link';
import { Icon } from './Icon';

/** Numbered pagination using ?page=N links (works without JavaScript, crawlable). */
export function Pagination({ current, total, basePath }: { current: number; total: number; basePath: string }) {
  if (total <= 1) return null;
  const href = (p: number) => (p === 1 ? basePath : `${basePath}?page=${p}`);
  const pages = Array.from({ length: total }, (_, i) => i + 1).filter((p) => p === 1 || p === total || Math.abs(p - current) <= 1);
  const cell = 'inline-flex h-11 min-w-11 items-center justify-center px-3 font-bold transition-colors';
  return (
    <nav aria-label="صفحا" className="mt-10 flex flex-wrap items-center justify-center gap-2">
      {current > 1 ? (
        <Link href={href(current - 1)} rel="prev" className={`${cell} gap-1 border border-line hover:border-ink`}>
          <Icon name="chevronRight" size={16} /> پويون
        </Link>
      ) : null}
      {pages.map((p, i) => (
        <span key={p} className="flex items-center gap-2">
          {i > 0 && p - pages[i - 1] > 1 && <span className="text-steel">…</span>}
          <Link
            href={href(p)}
            aria-current={p === current ? 'page' : undefined}
            className={`${cell} ${p === current ? 'bg-brand text-white' : 'border border-line hover:border-ink'}`}
          >
            {p}
          </Link>
        </span>
      ))}
      {current < total ? (
        <Link href={href(current + 1)} rel="next" className={`${cell} gap-1 bg-ink text-white hover:bg-brand`}>
          ايندڙ <Icon name="chevronLeft" size={16} />
        </Link>
      ) : null}
    </nav>
  );
}
