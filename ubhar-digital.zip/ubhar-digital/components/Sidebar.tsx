import Link from 'next/link';
import type { Article } from '@/lib/types';
import { MostRead } from './MostRead';
import { NewsCard } from './NewsCard';
import { NewsletterForm } from './Newsletter';
import { SocialLinks } from './SocialLinks';
import { Icon } from './Icon';

export function Sidebar({ mostRead, latest }: { mostRead: Article[]; latest?: Article[] }) {
  return (
    <aside className="space-y-8 lg:sticky lg:top-20">
      <MostRead articles={mostRead} />

      {latest && latest.length > 0 && (
        <section aria-labelledby="side-latest">
          <h2 id="side-latest" className="mb-4 border-b-[3px] border-brand pb-2 text-lg">
            تازيون خبرون
          </h2>
          <div className="space-y-4">
            {latest.map((a) => (
              <NewsCard key={a.slug} article={a} variant="compact" />
            ))}
          </div>
        </section>
      )}

      <section className="relative overflow-hidden bg-brand p-5 text-white">
        <div aria-hidden className="absolute -top-10 -end-10 size-32 rounded-full border border-white/30" />
        <h2 className="text-lg">اُڀار سان گڏ رهو</h2>
        <p className="mt-1 mb-3 text-sm text-white/85">روزانو اهم خبرون سڌو توهان جي اي ميل ۾.</p>
        <NewsletterForm compact />
        <SocialLinks size={16} itemClassName="text-white hover:text-ink" className="-ms-2 mt-1" />
      </section>

      <Link
        href="/advertise"
        className="flex aspect-[6/5] flex-col items-center justify-center gap-2 border-2 border-dashed border-line bg-mist p-6 text-center text-steel transition-colors hover:border-brand hover:text-brand"
      >
        <Icon name="megaphone" size={28} />
        <span className="font-bold">اشتهار لاءِ جڳهه</span>
        <span className="text-xs">300 × 250 — اُڀار تي پنهنجو برانڊ پيش ڪريو</span>
      </Link>
    </aside>
  );
}
