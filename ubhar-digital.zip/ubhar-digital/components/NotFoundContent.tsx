import Link from 'next/link';
import { Icon } from './Icon';

export function NotFoundContent() {
  return (
    <div className="container-x flex flex-col items-center py-20 text-center md:py-28">
      <div className="relative flex size-40 items-center justify-center">
        <span className="absolute inset-0 rounded-full border border-brand" />
        <span className="absolute inset-5 rounded-full bg-brand" />
        <span className="ltr relative font-display text-5xl font-black text-white">404</span>
      </div>
      <h1 className="mt-8 text-3xl md:text-4xl">صفحو نه مليو</h1>
      <p className="mt-3 max-w-md font-naskh text-lg leading-9 text-slate">جيڪو صفحو توهان ڳولي رهيا آهيو، اهو هٽايو ويو آهي يا ان جو پتو بدلجي ويو آهي.</p>
      <form action="/search" role="search" className="mt-8 flex w-full max-w-md border-2 border-ink">
        <label htmlFor="nf-q" className="sr-only">
          ڳولا
        </label>
        <input id="nf-q" name="q" type="search" placeholder="خبر ڳوليو..." className="h-12 min-w-0 flex-1 px-4 outline-none" />
        <button type="submit" aria-label="ڳوليو" className="flex w-12 items-center justify-center bg-brand text-white">
          <Icon name="search" size={20} />
        </button>
      </form>
      <Link href="/" className="mt-6 inline-flex h-12 items-center gap-2 bg-ink px-6 font-bold text-white hover:bg-brand">
        هوم پيج ڏانهن وڃو <Icon name="arrowLeft" size={16} />
      </Link>
    </div>
  );
}
