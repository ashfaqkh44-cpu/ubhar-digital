import Image from 'next/image';
import Link from 'next/link';
import { site } from '@/lib/site';

/**
 * Official UBHAR logo. The PNGs in /public/images/logo are cut directly from the
 * supplied brand artwork — proportions are never altered (width is derived from height).
 * Replace those files to update the logo everywhere.
 */
const LOGOS = {
  mark: { src: site.logo, w: 365, h: 344 },
  tagline: { src: site.logoWithTagline, w: 391, h: 416 },
} as const;

export function Logo({
  height = 56,
  variant = 'mark',
  priority = false,
  className = '',
  link = true,
  imgClassName,
}: {
  height?: number;
  /** Responsive height classes, e.g. "h-[60px] md:h-[80px] w-auto" (overrides fixed height) */
  imgClassName?: string;
  variant?: keyof typeof LOGOS;
  priority?: boolean;
  className?: string;
  link?: boolean;
}) {
  const logo = LOGOS[variant];
  const width = Math.round((height * logo.w) / logo.h);
  const img = (
    <Image
      src={logo.src}
      alt="اُڀار | UBHAR"
      width={width}
      height={height}
      priority={priority}
      sizes={`${width}px`}
      className={`block max-w-none ${imgClassName ?? 'h-auto'}`}
      style={imgClassName ? undefined : { width, height }}
    />
  );
  if (!link) return <span className={className}>{img}</span>;
  return (
    <Link href="/" aria-label="اُڀار ڊجيٽل — هوم پيج" className={`inline-flex shrink-0 ${className}`}>
      {img}
    </Link>
  );
}
