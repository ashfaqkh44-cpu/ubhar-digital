import type { Article, Category } from '@/lib/types';
import { NewsCard } from './NewsCard';
import { SectionHeading } from './SectionHeading';

type Layout = 'lead' | 'grid' | 'column';

/**
 * Editorial block for one category.
 *  - lead:   big overlay story + 4 side stories
 *  - grid:   4 cards in a row
 *  - column: narrow column (used two-up), lead card + compact list
 */
export function CategorySection({
  category,
  articles,
  layout = 'grid',
  className = '',
}: {
  category: Category;
  articles: Article[];
  layout?: Layout;
  className?: string;
}) {
  if (!articles.length) return null;
  const href = `/category/${category.slug}`;
  const id = `sec-${category.slug}`;

  if (layout === 'lead') {
    const [lead, ...rest] = articles;
    return (
      <section aria-labelledby={id} className={className}>
        <SectionHeading id={id} title={category.name} href={href} />
        <div className="grid gap-6 lg:grid-cols-12 lg:gap-8">
          <NewsCard article={lead} variant="overlay" className="lg:col-span-7" />
          <div className="flex flex-col gap-5 lg:col-span-5">
            {rest.slice(0, 4).map((a, i) => (
              <NewsCard key={a.slug} article={a} variant="horizontal" showSummary={false} showCategory={false} className={i > 0 ? 'border-t border-line pt-5' : ''} />
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (layout === 'column') {
    const [lead, ...rest] = articles;
    return (
      <section aria-labelledby={id} className={className}>
        <SectionHeading id={id} title={category.name} href={href} />
        <NewsCard article={lead} showCategory={false} />
        <div className="mt-5 flex flex-col gap-4 border-t border-line pt-5">
          {rest.slice(0, 3).map((a) => (
            <NewsCard key={a.slug} article={a} variant="compact" showCategory={false} />
          ))}
        </div>
      </section>
    );
  }

  return (
    <section aria-labelledby={id} className={className}>
      <SectionHeading id={id} title={category.name} href={href} />
      <div className="grid gap-x-6 gap-y-9 sm:grid-cols-2 lg:grid-cols-4">
        {articles.slice(0, 4).map((a) => (
          <NewsCard key={a.slug} article={a} showCategory={false} />
        ))}
      </div>
    </section>
  );
}
