'use client';

import { useState, type FormEvent } from 'react';
import { Icon } from './Icon';

export const CONTACT_SUBJECTS = [
  { value: 'general', label: 'عام رابطو' },
  { value: 'news-tip', label: 'خبر يا ٽپ موڪليو' },
  { value: 'public-voice', label: 'عوام جو آواز — مسئلو / رپورٽ' },
  { value: 'correction', label: 'درستگي / شڪايت' },
  { value: 'advertising', label: 'اشتهار ۽ ميڊيا سروسز' },
] as const;

type Fields = { name: string; email: string; phone: string; subject: string; message: string };
type Errors = Partial<Record<keyof Fields, string>>;

function validate(f: Fields): Errors {
  const e: Errors = {};
  if (f.name.trim().length < 2) e.name = 'مهرباني ڪري پنهنجو نالو لکو.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email.trim())) e.email = 'صحيح اي ميل ايڊريس لکو.';
  if (f.phone.trim() && !/^\+?[0-9\s-]{10,15}$/.test(f.phone.trim())) e.phone = 'فون نمبر صحيح ناهي (مثال: 03001234567).';
  if (!f.subject) e.subject = 'موضوع چونڊيو.';
  if (f.message.trim().length < 15) e.message = 'پيغام گهٽ ۾ گهٽ 15 اکرن جو هجي.';
  return e;
}

export function ContactForm({ defaultSubject = 'general' }: { defaultSubject?: string }) {
  const [fields, setFields] = useState<Fields>({ name: '', email: '', phone: '', subject: defaultSubject, message: '' });
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [serverMsg, setServerMsg] = useState('');

  const set = (k: keyof Fields) => (e: { target: { value: string } }) => {
    setFields((f) => ({ ...f, [k]: e.target.value }));
    if (errors[k]) setErrors((er) => ({ ...er, [k]: undefined }));
  };

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    const errs = validate(fields);
    setErrors(errs);
    if (Object.keys(errs).length) {
      const first = Object.keys(errs)[0];
      document.getElementById(`cf-${first}`)?.focus();
      return;
    }
    setStatus('loading');
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(fields),
      });
      const data = (await res.json()) as { ok: boolean; message?: string };
      if (!res.ok || !data.ok) throw new Error(data.message);
      setStatus('success');
      setServerMsg(data.message ?? '');
    } catch (err) {
      setStatus('error');
      setServerMsg(err instanceof Error && err.message ? err.message : 'پيغام نه موڪلي سگهياسين. ٻيهر ڪوشش ڪريو.');
    }
  }

  if (status === 'success') {
    return (
      <div className="border-t-4 border-brand bg-mist p-8 text-center" role="status">
        <span className="mx-auto flex size-14 items-center justify-center rounded-full bg-brand text-white">
          <Icon name="check" size={28} />
        </span>
        <h3 className="mt-4 text-2xl">شڪريه، {fields.name}!</h3>
        <p className="mt-2 font-naskh leading-8 text-slate">{serverMsg || 'توهان جو پيغام اسان کي ملي ويو آهي. اسان جلد رابطو ڪنداسين.'}</p>
        <button
          type="button"
          onClick={() => {
            setFields({ name: '', email: '', phone: '', subject: defaultSubject, message: '' });
            setStatus('idle');
          }}
          className="mt-6 inline-flex h-11 items-center bg-ink px-5 font-bold text-white hover:bg-brand"
        >
          ٻيو پيغام موڪليو
        </button>
      </div>
    );
  }

  const input = (k: keyof Fields) =>
    `mt-1.5 block w-full border-2 bg-white px-4 py-3 text-base outline-none transition-colors focus:border-ink ${errors[k] ? 'border-brand' : 'border-line'}`;
  const err = (k: keyof Fields) =>
    errors[k] ? (
      <p id={`cf-${k}-err`} className="mt-1 text-sm font-semibold text-brand">
        {errors[k]}
      </p>
    ) : null;

  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-5 sm:grid-cols-2">
      <div>
        <label htmlFor="cf-name" className="font-bold">
          نالو <span className="text-brand">*</span>
        </label>
        <input id="cf-name" value={fields.name} onChange={set('name')} autoComplete="name" aria-invalid={!!errors.name} aria-describedby="cf-name-err" className={input('name')} />
        {err('name')}
      </div>
      <div>
        <label htmlFor="cf-email" className="font-bold">
          اي ميل <span className="text-brand">*</span>
        </label>
        <input id="cf-email" type="email" dir="ltr" value={fields.email} onChange={set('email')} autoComplete="email" aria-invalid={!!errors.email} aria-describedby="cf-email-err" className={`${input('email')} text-start`} />
        {err('email')}
      </div>
      <div>
        <label htmlFor="cf-phone" className="font-bold">
          فون نمبر <span className="text-sm font-normal text-steel">(اختياري)</span>
        </label>
        <input id="cf-phone" type="tel" dir="ltr" value={fields.phone} onChange={set('phone')} autoComplete="tel" placeholder="03XX XXXXXXX" aria-invalid={!!errors.phone} aria-describedby="cf-phone-err" className={`${input('phone')} text-start`} />
        {err('phone')}
      </div>
      <div>
        <label htmlFor="cf-subject" className="font-bold">
          موضوع <span className="text-brand">*</span>
        </label>
        <select id="cf-subject" value={fields.subject} onChange={set('subject')} aria-invalid={!!errors.subject} className={input('subject')}>
          {CONTACT_SUBJECTS.map((s) => (
            <option key={s.value} value={s.value}>
              {s.label}
            </option>
          ))}
        </select>
        {err('subject')}
      </div>
      <div className="sm:col-span-2">
        <label htmlFor="cf-message" className="font-bold">
          پيغام <span className="text-brand">*</span>
        </label>
        <textarea id="cf-message" rows={6} value={fields.message} onChange={set('message')} aria-invalid={!!errors.message} aria-describedby="cf-message-err" className={`${input('message')} font-naskh leading-8`} />
        {err('message')}
      </div>
      <div className="flex flex-wrap items-center gap-4 sm:col-span-2">
        <button type="submit" disabled={status === 'loading'} className="inline-flex h-13 items-center gap-2 bg-brand px-8 font-bold text-white transition-colors hover:bg-brand-dark disabled:opacity-60">
          {status === 'loading' ? 'موڪلي رهيا آهيون...' : 'پيغام موڪليو'}
          <Icon name="arrowLeft" size={16} />
        </button>
        {status === 'error' && (
          <p role="alert" className="font-semibold text-brand">
            {serverMsg}
          </p>
        )}
      </div>
    </form>
  );
}
