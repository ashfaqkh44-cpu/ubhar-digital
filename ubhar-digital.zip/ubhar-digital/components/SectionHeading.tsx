import Link from 'next/link';
import { Icon } from './Icon';

/** Section title with UBHAR red accents and an optional "see all" link. */
export function SectionHeading({
  title,
  href,
  linkLabel = 'سڀ خبرون ڏسو',
  dark = false,
  as: As = 'h2',
  id,
}: {
  title: string;
  href?: string;
  linkLabel?: string;
  dark?: boolean;
  as?: 'h2' | 'h3';
  id?: string;
}) {
  return (
    <div className={`mb-6 flex items-end justify-between gap-4 border-b ${dark ? 'border-white/15' : 'border-line'}`}>
      <As id={id} className={`-mb-px flex items-center gap-3 border-b-[3px] border-brand pb-2.5 text-[1.45rem] leading-tight md:text-[1.7rem] ${dark ? 'text-white' : 'text-ink'}`}>
        <span className="relative inline-flex size-4 shrink-0 items-center justify-center" aria-hidden>
          <span className="absolute inset-0 rounded-full border border-brand" />
          <span className="size-2 rounded-full bg-brand" />
        </span>
        {title}
      </As>
      {href && (
        <Link
          href={href}
          className={`mb-2.5 inline-flex shrink-0 items-center gap-1 text-sm font-bold transition-colors ${
            dark ? 'text-white/70 hover:text-brand' : 'text-slate hover:text-brand'
          }`}
        >
          {linkLabel}
          <Icon name="arrowLeft" size={16} />
        </Link>
      )}
    </div>
  );
}
