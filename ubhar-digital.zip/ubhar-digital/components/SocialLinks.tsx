import { Icon } from './Icon';
import { site, socialList } from '@/lib/site';

export function SocialLinks({
  size = 16,
  className = '',
  itemClassName = 'text-white/70 hover:text-white',
  boxed = false,
}: {
  size?: number;
  className?: string;
  itemClassName?: string;
  boxed?: boolean;
}) {
  return (
    <ul className={`flex items-center gap-1 ${className}`} aria-label="سوشل ميڊيا">
      {socialList.map((s) => (
        <li key={s.key}>
          <a
            href={site.social[s.key]}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`اُڀار ${s.label} تي`}
            title={s.label}
            className={`inline-flex items-center justify-center transition-colors ${
              boxed ? 'size-10 border border-current/20 hover:border-brand hover:bg-brand hover:text-white' : 'size-8'
            } ${itemClassName}`}
          >
            <Icon name={s.key} size={size} />
          </a>
        </li>
      ))}
    </ul>
  );
}
