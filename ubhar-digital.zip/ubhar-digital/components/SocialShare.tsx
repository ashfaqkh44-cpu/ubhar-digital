'use client';

import { useEffect, useState } from 'react';
import { Icon, type IconName } from './Icon';

export function SocialShare({ url, title, className = '' }: { url: string; title: string; className?: string }) {
  const [copied, setCopied] = useState(false);
  const [canNativeShare, setCanNativeShare] = useState(false);
  useEffect(() => setCanNativeShare(typeof navigator !== 'undefined' && 'share' in navigator), []);

  const u = encodeURIComponent(url);
  const t = encodeURIComponent(title);
  const links: { name: string; icon: IconName; href: string; cls: string }[] = [
    { name: 'Facebook', icon: 'facebook', href: `https://www.facebook.com/sharer/sharer.php?u=${u}`, cls: 'hover:bg-[#1877F2]' },
    { name: 'WhatsApp', icon: 'whatsapp', href: `https://wa.me/?text=${t}%20${u}`, cls: 'hover:bg-[#25D366]' },
    { name: 'X', icon: 'x', href: `https://x.com/intent/post?text=${t}&url=${u}`, cls: 'hover:bg-black' },
  ];

  async function copy() {
    try {
      await navigator.clipboard.writeText(url);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = url;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  const btn = 'inline-flex size-10 items-center justify-center bg-ink text-white transition-colors';
  return (
    <div className={`flex flex-wrap items-center gap-2 ${className}`}>
      <span className="me-1 text-sm font-bold text-slate">شيئر ڪريو:</span>
      {links.map((l) => (
        <a key={l.name} href={l.href} target="_blank" rel="noopener noreferrer" aria-label={`${l.name} تي شيئر ڪريو`} title={l.name} className={`${btn} ${l.cls}`}>
          <Icon name={l.icon} size={17} />
        </a>
      ))}
      <button type="button" onClick={copy} aria-label="لنڪ ڪاپي ڪريو" title="لنڪ ڪاپي ڪريو" className={`${btn} hover:bg-brand ${copied ? '!bg-brand' : ''}`}>
        <Icon name={copied ? 'check' : 'link'} size={17} />
      </button>
      {canNativeShare && (
        <button
          type="button"
          onClick={() => navigator.share({ title, url }).catch(() => {})}
          className="inline-flex h-10 items-center gap-2 border border-ink px-3 text-sm font-bold hover:bg-ink hover:text-white sm:hidden"
        >
          ٻيا آپشن
        </button>
      )}
      <span role="status" aria-live="polite" className="text-sm font-bold text-brand">
        {copied ? 'لنڪ ڪاپي ٿي وئي!' : ''}
      </span>
    </div>
  );
}
